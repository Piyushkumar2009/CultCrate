'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Rss,
  Sliders,
  Sparkles,
  Users,
  Dna,
  RefreshCw,
  Filter,
  CheckCircle2,
  Tv,
  Film,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

export function HowItWorksBento() {
  // Interactive Duo Mode State
  const duoProfiles = [
    {
      user1: 'cinephile_99',
      user1Vibe: 'Giallo · Slow Cinema',
      user2: 'elena_films',
      user2Vibe: 'Body Horror · Neo-Noir',
      overlap: 88.4,
      mutualMatch: 'Possession (1981, Żuławski)',
      mutualGenre: 'Psychological Splatter / Cold War Allegory',
    },
    {
      user1: 'tarkovsky_boy',
      user1Vibe: 'Poetic Realism · Soviet Sci-Fi',
      user2: 'celluloid_queen',
      user2Vibe: 'Japanese New Wave · Surrealism',
      overlap: 93.2,
      mutualMatch: 'The Hourglass Sanatorium (1973, Has)',
      mutualGenre: 'Metaphysical Dreamscape / Nonlinear Memory',
    },
    {
      user1: 'noir_enthusiast',
      user1Vibe: 'French Extremity · Neo-Noir',
      user2: 'david_f',
      user2Vibe: 'Procedural Thriller · Precision Edit',
      overlap: 84.7,
      mutualMatch: 'Cure (1997, K. Kurosawa)',
      mutualGenre: 'Hypnotic Nihilism / Clinical Procedural',
    },
  ];

  const [activeDuoIndex, setActiveDuoIndex] = useState(0);
  const activeDuo = duoProfiles[activeDuoIndex];

  // Interactive DNA Profiler Tab
  const [activeDnaCategory, setActiveDnaCategory] = useState<'directors' | 'aesthetics' | 'pacing'>('directors');

  // Interactive RSS Sync Simulator
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState('All 482 diary records synchronized');
  const [lastSyncMinutes, setLastSyncMinutes] = useState(4);

  const handleManualSync = () => {
    setIsSyncing(true);
    setSyncStatus('Querying Letterboxd public RSS endpoint...');
    setTimeout(() => {
      setSyncStatus('Ingesting newest logged review: "Decision to Leave (★★★★½)"...');
    }, 800);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus('483 entries synced · Genome updated');
      setLastSyncMinutes(0);
    }, 1800);
  };

  // Interactive Exclusion Filters
  const [activeFilters, setActiveFilters] = useState<string[]>([
    'Criterion Channel',
    'MUBI',
    'Kanopy',
    'No Jump Scares',
  ]);

  const toggleFilter = (filterName: string) => {
    setActiveFilters((prev) =>
      prev.includes(filterName) ? prev.filter((f) => f !== filterName) : [...prev, filterName]
    );
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* 3-Step Explainer Section Header */}
      <div id="how-it-works" className="flex flex-col items-center text-center max-w-3xl mx-auto mb-14">
        <span className="text-xs font-mono font-semibold text-[#F59E0B] uppercase tracking-widest">
          Engine Architecture
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-2">
          Three steps between you and forgotten cinema masterpieces.
        </h2>
        <p className="text-sm sm:text-base text-[#9CA3AF] mt-3 leading-relaxed">
          Engineered around Gemini AI cognitive latent spaces and uncompressed Letterboxd diary streams.
        </p>
      </div>

      {/* 3-Step Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
        {/* Step 1 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="group relative rounded-2xl bg-[#121620]/80 border border-[#232936] p-6 sm:p-7 flex flex-col justify-between hover:border-[#E50914]/40 hover:bg-[#121620] transition-all shadow-lg"
        >
          <div>
            <div className="flex items-center justify-between mb-5">
              <span className="text-xs font-mono font-bold text-[#E50914] tracking-widest">
                PHASE 01
              </span>
              <div className="w-10 h-10 rounded-xl bg-[#090D16] border border-[#232936] flex items-center justify-center text-[#4EDEAE]">
                <Rss className="w-5 h-5 text-[#4EDEAE]" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-white">Connect Letterboxd</h3>
            <p className="text-sm text-[#9CA3AF] mt-2 leading-relaxed">
              Link your username or upload your diary CSV export. No manual entry. Our engine immediately ingests your lifetime ratings, logged rewatches, and subtle curatorial biases.
            </p>
          </div>

          {/* Micro-UI */}
          <div className="mt-6 p-3 rounded-xl bg-[#090D16]/90 border border-[#232936] flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-mono text-white">
              <span className="text-[#9CA3AF]">@</span>
              <span className="font-semibold">cinephile_99</span>
            </div>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-mono text-[#4EDEAE] bg-[#4EDEAE]/10 px-2 py-0.5 rounded border border-[#4EDEAE]/30">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4EDEAE]" />
              <span>Auto-Synced</span>
            </div>
          </div>
        </motion.div>

        {/* Step 2 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="group relative rounded-2xl bg-[#121620]/80 border border-[#232936] p-6 sm:p-7 flex flex-col justify-between hover:border-[#F59E0B]/40 hover:bg-[#121620] transition-all shadow-lg"
        >
          <div>
            <div className="flex items-center justify-between mb-5">
              <span className="text-xs font-mono font-bold text-[#F59E0B] tracking-widest">
                PHASE 02
              </span>
              <div className="w-10 h-10 rounded-xl bg-[#090D16] border border-[#232936] flex items-center justify-center text-[#F59E0B]">
                <Sliders className="w-5 h-5 text-[#F59E0B]" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-white">Calibrate Deep Crate</h3>
            <p className="text-sm text-[#9CA3AF] mt-2 leading-relaxed">
              Dial your desired obscurity gradient—from celebrated Cannes winners to 1970s underground Polish surrealism that never surfaced on mainstream algorithms.
            </p>
          </div>

          {/* Micro-UI */}
          <div className="mt-6 p-3 rounded-xl bg-[#090D16]/90 border border-[#232936] flex flex-col gap-2">
            <div className="flex justify-between items-center text-[11px] font-mono">
              <span className="text-[#9CA3AF]">Lvl 1 (Cannes)</span>
              <span className="text-[#F59E0B] font-bold">Lvl 4 (Void Archive)</span>
            </div>
            <div className="relative h-2 w-full bg-[#232936] rounded-full overflow-hidden">
              <div className="h-full w-4/5 bg-gradient-to-r from-[#F59E0B] to-[#E50914] rounded-full" />
            </div>
          </div>
        </motion.div>

        {/* Step 3 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="group relative rounded-2xl bg-[#121620]/80 border border-[#232936] p-6 sm:p-7 flex flex-col justify-between hover:border-[#E50914]/40 hover:bg-[#121620] transition-all shadow-lg"
        >
          <div>
            <div className="flex items-center justify-between mb-5">
              <span className="text-xs font-mono font-bold text-[#E50914] tracking-widest">
                PHASE 03
              </span>
              <div className="w-10 h-10 rounded-xl bg-[#090D16] border border-[#232936] flex items-center justify-center text-[#E50914]">
                <Sparkles className="w-5 h-5 text-[#E50914]" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-white">Synthesize Cohorts</h3>
            <p className="text-sm text-[#9CA3AF] mt-2 leading-relaxed">
              Gemini synthesizes director genomes, cinematographer framing vectors, and sensory pacing into tight 5-film screening protocols complete with verified streaming links.
            </p>
          </div>

          {/* Micro-UI */}
          <div className="mt-6 p-3 rounded-xl bg-[#090D16]/90 border border-[#232936] flex flex-col gap-1">
            <div className="text-xs font-mono text-white truncate font-medium">
              Cohort: Tokyo Rain Neo-Noir
            </div>
            <div className="flex items-center justify-between text-[#9CA3AF] text-[11px] font-mono">
              <span>5 Titles In Vault</span>
              <span className="text-[#E50914] font-bold">98.2% Latent Match</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bento Grid Header */}
      <div id="dna-engine" className="flex flex-col items-center text-center max-w-3xl mx-auto mb-12">
        <span className="text-xs font-mono font-semibold text-[#E50914] uppercase tracking-widest">
          Vault Capabilities
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-2">
          Designed for obsessive cinephiles, not casual browsers.
        </h2>
      </div>

      {/* Bento Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Bento 1: Duo Mode (7 Cols) */}
        <motion.div
          id="duo-mode"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="lg:col-span-7 rounded-2xl bg-[#121620]/85 border border-[#232936] p-6 sm:p-8 flex flex-col justify-between shadow-xl"
        >
          <div>
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2 text-[#E50914] text-xs font-mono uppercase tracking-wider">
                <Users className="w-4 h-4" />
                <span>Synchronized Taste Cognition</span>
              </div>

              {/* Profile pair switcher */}
              <div className="flex items-center gap-1 bg-[#090D16] p-1 rounded-lg border border-[#232936]">
                {duoProfiles.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveDuoIndex(i)}
                    className={`text-[11px] font-mono px-2.5 py-1 rounded transition-colors ${
                      activeDuoIndex === i
                        ? 'bg-[#E50914] text-white font-bold'
                        : 'text-[#9CA3AF] hover:text-white'
                    }`}
                  >
                    Pair {i + 1}
                  </button>
                ))}
              </div>
            </div>

            <h3 className="text-2xl font-bold text-white mt-3">
              Duo Mode (Co-Screening Protocol)
            </h3>
            <p className="text-sm text-[#9CA3AF] mt-2 max-w-xl leading-relaxed">
              Merge two Letterboxd profiles to uncover the exact psychological and stylistic intersection where both viewers thrive. Zero endless scrolling, zero compromises.
            </p>
          </div>

          {/* Interactive Dual Diagram */}
          <div className="mt-6 p-5 rounded-xl bg-[#090D16]/90 border border-[#232936] relative overflow-hidden">
            <div className="flex flex-col sm:flex-row items-center justify-around gap-6 py-3">
              {/* Profile A */}
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-full bg-[#E50914]/15 border-2 border-[#E50914] flex items-center justify-center shadow-[0_0_20px_rgba(229,9,20,0.4)]">
                  <span className="text-lg font-mono font-bold text-white">
                    {activeDuo.user1.charAt(0).toUpperCase()}
                  </span>
                </div>
                <span className="text-xs font-mono text-white font-semibold mt-2">
                  @{activeDuo.user1}
                </span>
                <span className="text-[11px] text-[#9CA3AF] mt-0.5 max-w-[120px] truncate">
                  {activeDuo.user1Vibe}
                </span>
              </div>

              {/* Convergence Node */}
              <div className="flex flex-col items-center text-center px-4 py-3 rounded-xl bg-[#121620] border border-[#232936] shadow-md max-w-xs">
                <span className="text-2xl font-mono font-bold text-[#F59E0B]">
                  {activeDuo.overlap}%
                </span>
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#9CA3AF]">
                  Harmonic Overlap
                </span>
                <div className="mt-2 pt-2 border-t border-[#232936] w-full">
                  <span className="text-[10px] text-[#9CA3AF] uppercase block font-mono">
                    Mutual Screening Verdict:
                  </span>
                  <span className="text-xs font-bold text-[#4EDEAE] block mt-0.5">
                    {activeDuo.mutualMatch}
                  </span>
                  <span className="text-[10px] text-[#9CA3AF] block mt-0.5 italic">
                    {activeDuo.mutualGenre}
                  </span>
                </div>
              </div>

              {/* Profile B */}
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-full bg-[#4EDEAE]/15 border-2 border-[#4EDEAE] flex items-center justify-center shadow-[0_0_20px_rgba(78,222,174,0.4)]">
                  <span className="text-lg font-mono font-bold text-white">
                    {activeDuo.user2.charAt(0).toUpperCase()}
                  </span>
                </div>
                <span className="text-xs font-mono text-white font-semibold mt-2">
                  @{activeDuo.user2}
                </span>
                <span className="text-[11px] text-[#9CA3AF] mt-0.5 max-w-[120px] truncate">
                  {activeDuo.user2Vibe}
                </span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Bento 2: Cinematic DNA Profiler (5 Cols) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-5 rounded-2xl bg-[#121620]/85 border border-[#232936] p-6 sm:p-8 flex flex-col justify-between shadow-xl"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#F59E0B] text-xs font-mono uppercase tracking-wider">
                <Dna className="w-4 h-4" />
                <span>Neural Genome Metrics</span>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-white mt-3">Cinematic DNA Profiler</h3>
            <p className="text-sm text-[#9CA3AF] mt-2 leading-relaxed">
              Deep vectorization of your auteur affinities, pacing tolerances, and atmospheric density metrics.
            </p>
          </div>

          {/* DNA Genome Bars */}
          <div className="mt-6 p-4 rounded-xl bg-[#090D16]/90 border border-[#232936] flex flex-col gap-3.5">
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white">Denis Villeneuve (Atmosphere &amp; Scale)</span>
                <span className="text-[#E50914] font-bold">98%</span>
              </div>
              <div className="h-1.5 w-full bg-[#232936] rounded-full overflow-hidden">
                <div className="h-full bg-[#E50914] rounded-full w-[98%] shadow-[0_0_8px_rgba(229,9,20,0.8)]" />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white">Bong Joon-ho (Pacing Variance &amp; Satire)</span>
                <span className="text-[#F59E0B] font-bold">96%</span>
              </div>
              <div className="h-1.5 w-full bg-[#232936] rounded-full overflow-hidden">
                <div className="h-full bg-[#F59E0B] rounded-full w-[96%] shadow-[0_0_8px_rgba(245,158,11,0.8)]" />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white">David Fincher (Precision Procedural Edit)</span>
                <span className="text-[#4EDEAE] font-bold">94%</span>
              </div>
              <div className="h-1.5 w-full bg-[#232936] rounded-full overflow-hidden">
                <div className="h-full bg-[#4EDEAE] rounded-full w-[94%] shadow-[0_0_8px_rgba(78,222,174,0.8)]" />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white">Kiyoshi Kurosawa (Spatial Dread &amp; Wind)</span>
                <span className="text-red-400 font-bold">92%</span>
              </div>
              <div className="h-1.5 w-full bg-[#232936] rounded-full overflow-hidden">
                <div className="h-full bg-red-400 rounded-full w-[92%]" />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Bento 3: Continuous RSS Auto-Sync (6 Cols) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.15 }}
          className="lg:col-span-6 rounded-2xl bg-[#121620]/85 border border-[#232936] p-6 sm:p-8 flex flex-col justify-between shadow-xl"
        >
          <div>
            <div className="flex items-center gap-2 text-[#4EDEAE] text-xs font-mono uppercase tracking-wider">
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>Real-Time Letterboxd Pipeline</span>
            </div>
            <h3 className="text-2xl font-bold text-white mt-3">Continuous RSS Auto-Sync</h3>
            <p className="text-sm text-[#9CA3AF] mt-2 leading-relaxed">
              Background workers ingest every log, review, and list update automatically via Letterboxd&apos;s public RSS stream. Zero manual export uploads required.
            </p>
          </div>

          <div className="mt-6 p-4 rounded-xl bg-[#090D16]/90 border border-[#232936] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-xs font-mono text-[#9CA3AF]">
                Last Trigger: <span className="text-white font-semibold">{lastSyncMinutes} mins ago</span>
              </div>
              <div className="text-xs text-[#4EDEAE] font-mono mt-0.5 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#4EDEAE] animate-pulse" />
                <span>{syncStatus}</span>
              </div>
            </div>

            <button
              onClick={handleManualSync}
              disabled={isSyncing}
              className="px-3.5 py-1.5 rounded-lg bg-[#121620] border border-[#232936] hover:border-[#4EDEAE]/50 text-xs font-mono text-white flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-[#4EDEAE]' : ''}`} />
              <span>{isSyncing ? 'Syncing...' : 'Simulate Ping'}</span>
            </button>
          </div>
        </motion.div>

        {/* Bento 4: Zero Spoilers & Exclusion Filter (6 Cols) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-6 rounded-2xl bg-[#121620]/85 border border-[#232936] p-6 sm:p-8 flex flex-col justify-between shadow-xl"
        >
          <div>
            <div className="flex items-center gap-2 text-[#E50914] text-xs font-mono uppercase tracking-wider">
              <Filter className="w-4 h-4" />
              <span>Surgical Filtering &amp; Quarantine</span>
            </div>
            <h3 className="text-2xl font-bold text-white mt-3">Zero Spoilers &amp; Exclusions</h3>
            <p className="text-sm text-[#9CA3AF] mt-2 leading-relaxed">
              Prune jump scares, Hollywood tropes, or disliked directors. Every suggestion includes verified streaming availability across Criterion Channel, MUBI, Kanopy, and Prime.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            {[
              'Criterion Channel',
              'MUBI',
              'Kanopy',
              'Arrow Player',
              'No Jump Scares',
              '100% Spoiler Clean',
            ].map((filter) => {
              const active = activeFilters.includes(filter);
              return (
                <button
                  key={filter}
                  onClick={() => toggleFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono flex items-center gap-1.5 transition-all ${
                    active
                      ? 'bg-[#E50914]/20 border border-[#E50914] text-white shadow-[0_0_10px_rgba(229,9,20,0.3)]'
                      : 'bg-[#090D16] border border-[#232936] text-[#9CA3AF] hover:text-white'
                  }`}
                >
                  <CheckCircle2
                    className={`w-3.5 h-3.5 ${active ? 'text-[#E50914]' : 'text-[#6B7280]'}`}
                  />
                  <span>{filter}</span>
                </button>
              );
            })}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
