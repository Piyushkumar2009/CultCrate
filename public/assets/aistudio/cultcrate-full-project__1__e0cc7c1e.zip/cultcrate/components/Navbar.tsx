'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Film, Sparkles, LogIn, Menu, X, Radio } from 'lucide-react';

interface NavbarProps {
  onOpenSignIn?: () => void;
  onOpenGetStarted?: () => void;
  activeSection?: string;
}

export function Navbar({ onOpenSignIn, onOpenGetStarted }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-[#090D16]/85 backdrop-blur-xl border-b border-[#232936]/80 shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
      <div className="max-w-7xl mx-auto h-20 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link
          href="/"
          className="group flex items-center gap-3 transition-transform active:scale-95"
        >
          <div className="w-10 h-10 rounded-xl bg-[#121620] border border-[#232936] flex items-center justify-center shadow-[0_0_24px_rgba(229,9,20,0.35)] group-hover:shadow-[0_0_30px_rgba(229,9,20,0.65)] group-hover:border-[#E50914]/40 transition-all">
            <Film className="w-5 h-5 text-[#E50914]" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight text-white leading-none">
              Cult<span className="text-[#E50914]">Crate</span>
            </span>
            <span className="text-[10px] font-mono tracking-wider text-[#9CA3AF] uppercase mt-0.5">
              Screening Vault
            </span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1 p-1 rounded-full bg-[#121620]/80 border border-[#232936]">
          <button
            onClick={() => scrollTo('how-it-works')}
            className="px-4 py-1.5 rounded-full text-sm font-medium text-[#9CA3AF] hover:text-white hover:bg-[#191F2C] transition-colors"
          >
            How It Works
          </button>
          <button
            onClick={() => scrollTo('vault-preview')}
            className="px-4 py-1.5 rounded-full text-sm font-medium text-[#9CA3AF] hover:text-white hover:bg-[#191F2C] transition-colors"
          >
            Vault
          </button>
          <button
            onClick={() => scrollTo('dna-engine')}
            className="px-4 py-1.5 rounded-full text-sm font-medium text-[#9CA3AF] hover:text-white hover:bg-[#191F2C] transition-colors"
          >
            DNA Engine
          </button>
          <button
            onClick={() => scrollTo('duo-mode')}
            className="px-4 py-1.5 rounded-full text-sm font-medium text-[#9CA3AF] hover:text-white hover:bg-[#191F2C] transition-colors"
          >
            Duo Mode
          </button>
          <button
            onClick={() => scrollTo('vault-archive')}
            className="px-4 py-1.5 rounded-full text-sm font-medium text-[#9CA3AF] hover:text-white hover:bg-[#191F2C] transition-colors"
          >
            Cohort Archive
          </button>
        </nav>

        {/* Action CTAs */}
        <div className="flex items-center gap-3">
          <div className="hidden xl:flex items-center gap-2 px-3 py-1 rounded-full bg-[#121620] border border-[#232936] text-[11px] font-mono text-[#4EDEAE]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#4EDEAE] animate-pulse" />
            <span>Nodes Online</span>
          </div>

          <Link
            href="/auth"
            className="hidden sm:inline-flex items-center gap-1.5 text-sm font-medium text-[#9CA3AF] hover:text-white transition-colors px-3 py-2"
          >
            <LogIn className="w-4 h-4 text-[#9CA3AF]" />
            <span>Sign In</span>
          </Link>

          {/* Sleek, Compact "Get Started" CTA */}
          <Link
            href="/auth"
            className="group relative inline-flex items-center justify-center gap-1.5 px-3 py-1.5 sm:px-4 sm:py-2 rounded-full bg-[#E50914] text-white font-semibold text-xs sm:text-sm shadow-[0_0_20px_rgba(229,9,20,0.4)] hover:shadow-[0_0_30px_rgba(229,9,20,0.7)] hover:bg-[#f40612] hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Get Started</span>
          </Link>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl bg-[#121620] border border-[#232936] text-[#9CA3AF] hover:text-white"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#090D16]/95 border-b border-[#232936] px-4 py-4 space-y-2 backdrop-blur-xl">
          <button
            onClick={() => scrollTo('how-it-works')}
            className="w-full text-left px-4 py-2.5 rounded-lg text-sm text-[#9CA3AF] hover:text-white hover:bg-[#121620]"
          >
            How It Works
          </button>
          <button
            onClick={() => scrollTo('vault-preview')}
            className="w-full text-left px-4 py-2.5 rounded-lg text-sm text-[#9CA3AF] hover:text-white hover:bg-[#121620]"
          >
            Vault &amp; Interactive Slider
          </button>
          <button
            onClick={() => scrollTo('dna-engine')}
            className="w-full text-left px-4 py-2.5 rounded-lg text-sm text-[#9CA3AF] hover:text-white hover:bg-[#121620]"
          >
            Cinematic DNA Engine
          </button>
          <button
            onClick={() => scrollTo('duo-mode')}
            className="w-full text-left px-4 py-2.5 rounded-lg text-sm text-[#9CA3AF] hover:text-white hover:bg-[#121620]"
          >
            Duo Mode (Co-Screening)
          </button>
          <button
            onClick={() => scrollTo('vault-archive')}
            className="w-full text-left px-4 py-2.5 rounded-lg text-sm text-[#9CA3AF] hover:text-white hover:bg-[#121620]"
          >
            Cohort Archive
          </button>
          <div className="pt-2 border-t border-[#232936] flex items-center justify-between">
            <Link
              href="/auth"
              onClick={() => setMobileMenuOpen(false)}
              className="text-sm font-medium text-[#9CA3AF] hover:text-white py-2"
            >
              Sign In (Letterboxd)
            </Link>
            <div className="flex items-center gap-1.5 text-xs font-mono text-[#4EDEAE]">
              <Radio className="w-3.5 h-3.5" />
              <span>Vault Active</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
