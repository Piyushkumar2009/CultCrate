'use client';

import React from 'react';
import Link from 'next/link';
import { Film } from 'lucide-react';

export function Footer() {
  return (
    <footer className="w-full bg-[#06090F] border-t border-[#232936] py-12 mt-20 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Left branding & copyright */}
        <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
          <Link href="/" className="flex items-center gap-2 group">
            <Film className="w-4 h-4 text-[#E50914] group-hover:scale-110 transition-transform" />
            <span className="font-bold text-white text-sm">
              Cult<span className="text-[#E50914]">Crate</span>
            </span>
          </Link>
          <span className="text-[#232936] hidden sm:inline">•</span>
          <span className="text-xs font-mono text-[#9CA3AF]">
            © {new Date().getFullYear()} CultCrate Screening Vault. All rights reserved.
          </span>
        </div>

        {/* Navigation Links */}
        <nav className="flex flex-wrap items-center justify-center gap-6 text-xs text-[#9CA3AF]">
          <Link href="/auth" className="hover:text-white transition-colors">
            Vault Sign In
          </Link>
          <a
            href="https://letterboxd.com"
            target="_blank"
            rel="noreferrer"
            className="hover:text-white transition-colors"
          >
            Letterboxd RSS Docs
          </a>
          <a
            href="https://ai.google.dev"
            target="_blank"
            rel="noreferrer"
            className="hover:text-white transition-colors"
          >
            Gemini AI Architecture
          </a>
          <a href="#how-it-works" className="hover:text-white transition-colors">
            How It Works
          </a>
          <a href="#duo-mode" className="hover:text-white transition-colors">
            Duo Mode
          </a>
        </nav>

        {/* Status node */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#121620] border border-[#232936] text-xs font-mono text-[#4EDEAE] shadow-[0_0_15px_-2px_rgba(78,222,174,0.2)]">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#4EDEAE] opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#4EDEAE]" />
          </span>
          <span className="uppercase tracking-wide font-semibold text-[11px]">
            Status: All Vault Nodes Online
          </span>
        </div>
      </div>
    </footer>
  );
}
