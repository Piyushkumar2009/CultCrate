'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Archive,
  Terminal,
  ExternalLink,
  Layers,
  Sparkles,
  Star,
  Film,
  Calendar,
  User,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import { FilmCohort } from '@/lib/vaultData';

interface VaultHistoryArchiveProps {
  cohorts: FilmCohort[];
  onOpenCohort: (cohort: FilmCohort) => void;
}

export function VaultHistoryArchive({ cohorts, onOpenCohort }: VaultHistoryArchiveProps) {
  const [selectedTag, setSelectedTag] = useState<string>('All');

  // Filter cohorts
  const filteredCohorts = cohorts.filter((c) => {
    if (selectedTag === 'All') return true;
    return (
      c.obscurityLabel.toLowerCase().includes(selectedTag.toLowerCase()) ||
      c.tags.some((t) => t.toLowerCase().includes(selectedTag.toLowerCase()))
    );
  });

  const filterTags = ['All', 'Level 4 Arthouse', 'Level 3 Cult Canon', 'Level 5 The Void', 'Masterpiece'];

  return (
    <section id="vault-archive" className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-[#232936]">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-semibold text-[#E50914] uppercase tracking-widest">
            <Archive className="w-4 h-4" />
            <span>Vault History &amp; Telemetry</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-2">
            Archived Screening Cohorts
          </h2>
          <p className="text-sm text-[#9CA3AF] mt-1">
            Access previous syntheses, director genome diagnostics, and custom 5-film lineups.
          </p>
        </div>

        {/* Filter Tags */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {filterTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
                selectedTag === tag
                  ? 'bg-[#E50914] text-white font-bold shadow-[0_0_12px_rgba(229,9,20,0.4)]'
                  : 'bg-[#121620] border border-[#232936] text-[#9CA3AF] hover:text-white hover:bg-[#191F2C]'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Cohorts */}
      <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {filteredCohorts.map((cohort, index) => (
          <motion.div
            key={cohort.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            className="group relative rounded-2xl bg-[#121620]/80 border border-[#232936] p-5 sm:p-6 flex flex-col justify-between hover:border-[#E50914]/40 hover:bg-[#121620] transition-all shadow-xl"
          >
            <div>
              {/* Cohort Header Meta */}
              <div className="flex items-center justify-between gap-2 text-xs font-mono pb-3 border-b border-[#232936]/60">
                <span className="text-[#F59E0B] font-semibold">{cohort.obscurityLabel}</span>
                <span className="text-[#4EDEAE] bg-[#4EDEAE]/10 px-2 py-0.5 rounded border border-[#4EDEAE]/30">
                  {cohort.matchScore} Fit
                </span>
              </div>

              {/* Title & Log */}
              <h3 className="text-lg font-bold text-white mt-3 group-hover:text-[#E50914] transition-colors leading-snug">
                {cohort.cohortTitle}
              </h3>

              <p className="text-xs text-[#9CA3AF] mt-2 line-clamp-2 leading-relaxed">
                {cohort.curatorialLog}
              </p>

              {/* Mini-Poster Stack Visualization */}
              <div className="mt-5 pt-3">
                <div className="flex items-center justify-between text-[11px] font-mono text-[#9CA3AF] mb-2">
                  <span className="flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5 text-[#E50914]" />
                    <span>5-Film Screening Protocol</span>
                  </span>
                  <span>@{cohort.letterboxdUser}</span>
                </div>

                {/* Overlapping poster stack */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1">
                  {cohort.films.map((film, fIdx) => (
                    <div
                      key={film.id || fIdx}
                      className="relative w-14 h-20 rounded-md overflow-hidden shrink-0 border border-red-950/40 bg-gradient-to-br from-neutral-900 via-zinc-950 to-black group/poster shadow-md flex flex-col justify-between text-[7px] font-mono leading-tight select-none p-1.5"
                      title={`${film.title} (${film.year}) - Dir: ${film.director}`}
                    >
                      <span className="text-[6px] text-red-500 font-bold uppercase">35mm</span>
                      <span className="font-bold text-zinc-100 truncate block my-auto">{film.title}</span>
                      <span className="text-zinc-500 font-bold">({film.year})</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tags */}
              <div className="mt-4 flex flex-wrap gap-1.5">
                {cohort.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-0.5 rounded bg-[#090D16] border border-[#232936] text-[10px] font-mono text-[#9CA3AF]"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Action CTA */}
            <div className="mt-6 pt-4 border-t border-[#232936] flex items-center justify-between">
              <span className="text-[11px] font-mono text-[#6B7280]">
                {cohort.createdDate}
              </span>

              <button
                onClick={() => onOpenCohort(cohort)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#090D16] border border-[#232936] hover:border-[#E50914] text-xs font-mono font-semibold text-white hover:text-[#E50914] transition-all group-hover:bg-[#191F2C]"
              >
                <span>Open Full Cohort</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Telemetry Stream Console */}
      <div className="mt-14 rounded-2xl bg-[#090D16] border border-[#232936] p-5 sm:p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-[#232936]">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#4EDEAE]" />
            <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
              Live Ingest &amp; Curatorial Telemetry Stream
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#4EDEAE]">
            <Radio className="w-3.5 h-3.5 animate-pulse" />
            <span>Streaming Daemon // Active</span>
          </div>
        </div>

        <div className="mt-4 font-mono text-xs text-[#9CA3AF] space-y-2 max-h-48 overflow-y-auto pr-2">
          <div className="flex items-start gap-2">
            <span className="text-[#6B7280] shrink-0">[21:24:02.189]</span>
            <span className="text-[#4EDEAE]">RSS_INGEST</span>
            <span className="text-white">Letterboxd stream parsed: 482 logged diary films ingested for @cinephile_99</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#6B7280] shrink-0">[21:24:15.340]</span>
            <span className="text-[#F59E0B]">GENOME_CALC</span>
            <span>Auteur vector alignment computed: Kiyoshi Kurosawa (99.1%), Bong Joon-ho (97.8%)</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#6B7280] shrink-0">[21:24:30.822]</span>
            <span className="text-[#E50914]">CRITERION_API</span>
            <span>Confirmed streaming availability: Criterion Channel &amp; Kanopy 4K master for &apos;Cure (1997)&apos;</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#6B7280] shrink-0">[21:25:01.455]</span>
            <span className="text-[#4EDEAE]">COHORT_SEAL</span>
            <span className="text-white">Screening Protocol &apos;Tokyo Rain Neo-Noir&apos; sealed into local AES-256 vault store</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#6B7280] shrink-0">[21:25:56.012]</span>
            <span className="text-[#9CA3AF]">DAEMON_PING</span>
            <span>Node cluster health: 5/5 micro-services responsive. Latency 14ms.</span>
          </div>
        </div>
      </div>
    </section>
  );
}
