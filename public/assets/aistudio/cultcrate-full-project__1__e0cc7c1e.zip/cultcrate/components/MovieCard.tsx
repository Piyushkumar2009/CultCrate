'use client';

import React from 'react';
import { Star, Play, ExternalLink, Bookmark } from 'lucide-react';

export interface MovieData {
  title: string;
  year?: string | number;
  rating?: string | number;
  genre?: string;
  reason?: string;
  director?: string;
  runtime?: string;
  matchScore?: string;
  category?: string;
}

export interface RecommendedFilm {
  id: string;
  title: string;
  originalTitle?: string;
  year: number;
  runtime: string;
  country: string;
  countryFlag?: string;
  director: string;
  imdbRating: string;
  letterboxdRating: string;
  posterUrl?: string;
  matchScore: string;
  obscurityBadge: string;
  obscurityLevel?: number;
  streamingPlatforms: string[];
  whereToWatchInIndia?: string[];
  contentAdvisory?: string;
  advisory?: string;
  synopsis: string;
  curatorialReason: string;
  trailerUrl?: string;
  letterboxdUrl?: string;
  genre?: string[];
  runtime_mins?: number;
  imdb_rating?: number;
  scale_projection?: string;
  rating?: string | number;
  reason?: string;
}

export interface MovieCardProps {
  movie?: MovieData;
  film?: RecommendedFilm;
  isWatchlisted?: boolean;
  onToggleWatchlist?: (id: string) => void;
  onWatchTrailer?: (film: any) => void;
}

export function MovieCard({
  movie,
  film,
  isWatchlisted = false,
  onToggleWatchlist,
  onWatchTrailer,
}: MovieCardProps) {
  const title = movie?.title || film?.title || 'Untitled Film';
  const year = movie?.year ?? film?.year ?? 'N/A';
  const rating =
    movie?.rating ||
    film?.letterboxdRating ||
    film?.imdbRating ||
    film?.rating ||
    '4.2';

  const genre =
    movie?.genre ||
    (Array.isArray(film?.genre)
      ? film.genre.join(' · ')
      : film?.genre || 'Arthouse · Cult Cinema');

  const reason =
    movie?.reason ||
    film?.curatorialReason ||
    film?.synopsis ||
    'Selected based on your verified Letterboxd taste vector.';

  const director = movie?.director || film?.director || 'Visionary Auteur';
  const runtime = movie?.runtime || film?.runtime || '112m';

  const fitScore =
    movie?.matchScore ||
    (film?.matchScore
      ? film.matchScore.includes('%')
        ? film.matchScore
        : `${film.matchScore}%`
      : '99.1%');

  const isMasterpiece =
    film?.obscurityBadge?.toLowerCase().includes('masterpiece') ||
    film?.scale_projection?.toLowerCase().includes('masterpiece');

  const category =
    movie?.category ||
    (isMasterpiece ? 'Auteur Masterpiece' : 'Auteur Alignment');

  const filmId = film?.id || title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const letterboxdLink =
    film?.letterboxdUrl ||
    `https://letterboxd.com/film/${encodeURIComponent(
      title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
    )}/`;

  return (
    <article className="group relative rounded-xl bg-[#090D16] border border-zinc-800/80 hover:border-red-600/40 hover:bg-[#121620] transition-all duration-300 p-4 sm:p-5 flex flex-col justify-between shadow-xl overflow-hidden select-none">
      {/* Background Volumetric Glow */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-red-600/5 rounded-full blur-3xl pointer-events-none -z-0" />

      {/* Top Meta Row: "Vault 35mm" badge & "Auteur Alignment" tag */}
      <div className="relative z-10 flex items-center justify-between gap-2 flex-wrap mb-3">
        <span className="text-[10px] font-mono tracking-widest text-red-500/90 uppercase font-bold bg-red-950/40 border border-red-900/40 px-2 py-0.5 rounded">
          Vault 35mm
        </span>

        <span className="border border-amber-500/30 bg-amber-500/10 text-amber-400 text-[10px] font-mono px-2 py-0.5 rounded uppercase tracking-wider font-semibold">
          {category}
        </span>
      </div>

      {/* Content Section */}
      <div className="relative z-10 space-y-2 mb-4">
        {/* Runtime & Genre Subheader */}
        <div className="text-zinc-400 text-xs font-mono flex items-center gap-1.5 flex-wrap">
          <span>{year}</span>
          <span>•</span>
          <span>{runtime}</span>
          {genre && (
            <>
              <span>•</span>
              <span className="text-zinc-300 truncate max-w-[200px] sm:max-w-none">
                {genre}
              </span>
            </>
          )}
        </div>

        {/* Movie Title (uppercase, bold) */}
        <h3 className="text-lg sm:text-xl font-black text-zinc-100 uppercase tracking-tight leading-snug group-hover:text-red-100 transition-colors">
          {title}
        </h3>

        {/* Italicized AI Rationale */}
        <p className="text-zinc-400 text-xs sm:text-sm line-clamp-3 leading-relaxed font-sans italic">
          &ldquo;{reason}&rdquo;
        </p>
      </div>

      {/* Footer Section */}
      <div className="relative z-10 pt-3 border-t border-zinc-800/80 flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Star rating badge (★ {rating} / 5) */}
          <div className="bg-red-950/50 text-red-400 border border-red-900/40 px-2.5 py-1 rounded-md text-xs font-mono font-bold flex items-center gap-1 shadow-sm">
            <Star className="w-3 h-3 fill-red-400 shrink-0" />
            <span>★ {rating} / 5</span>
          </div>

          {/* Green Fit percentage pill */}
          <span className="bg-emerald-950/40 text-emerald-400 border border-emerald-800/40 text-xs font-mono font-bold px-2.5 py-1 rounded-md shrink-0">
            {fitScore.endsWith('Fit') ? fitScore : `${fitScore} Fit`}
          </span>

          {/* Director tag */}
          <span className="text-xs font-mono text-zinc-300 bg-zinc-900/80 px-2.5 py-1 rounded-md border border-zinc-800 truncate max-w-[150px]">
            Dir. {director}
          </span>
        </div>

        {/* Interactive Actions */}
        <div className="flex items-center gap-2">
          {onWatchTrailer && film && (
            <button
              type="button"
              onClick={() => onWatchTrailer(film)}
              className="px-2.5 py-1 rounded-lg bg-red-600/10 hover:bg-red-600/20 text-red-400 border border-red-600/30 font-mono text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer active:scale-95"
              title="Watch Trailer"
            >
              <Play className="w-3 h-3 fill-current" />
              <span className="hidden sm:inline">Trailer</span>
            </button>
          )}

          <a
            href={letterboxdLink}
            target="_blank"
            rel="noreferrer"
            className="px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 font-mono text-xs flex items-center gap-1 transition-colors"
            title="Open Letterboxd"
          >
            <span>LB</span>
            <ExternalLink className="w-3 h-3" />
          </a>

          {onToggleWatchlist && (
            <button
              type="button"
              onClick={() => onToggleWatchlist(filmId)}
              className={`p-1.5 rounded-lg font-mono text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer active:scale-95 ${
                isWatchlisted
                  ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/50'
                  : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800'
              }`}
              title={isWatchlisted ? 'Remove from Watchlist' : 'Add to Watchlist'}
            >
              <Bookmark className={`w-3.5 h-3.5 ${isWatchlisted ? 'fill-emerald-400' : ''}`} />
            </button>
          )}
        </div>
      </div>
    </article>
  );
}

export default MovieCard;
