import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'CultCrate — AI-Powered Film Recommendation Vault',
  description: 'Unlock the cinematic underground. Calibrate curatorial obscurity, sync your Letterboxd RSS diary, and synthesize 5-film cohorts powered by Gemini AI.',
  openGraph: {
    title: 'CultCrate — AI-Powered Film Recommendation Vault',
    description: 'Unlock the cinematic underground. Calibrate curatorial obscurity, sync your Letterboxd RSS diary, and synthesize 5-film cohorts powered by Gemini AI.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'CultCrate — AI-Powered Film Recommendation Vault',
    description: 'Unlock the cinematic underground. Calibrate curatorial obscurity, sync your Letterboxd RSS diary, and synthesize 5-film cohorts powered by Gemini AI.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="bg-[#090D16] text-[#F9FAFB] min-h-screen antialiased selection:bg-[#E50914] selection:text-white overflow-x-hidden font-sans">
        {children}
      </body>
    </html>
  );
}
