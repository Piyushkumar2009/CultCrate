'use client';

import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText,
  Sparkles,
  Sliders,
  LogOut,
  Star,
  ExternalLink,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  Play,
  Bookmark,
  Tv,
  Film,
  AlertTriangle,
  X,
  Radio,
  Clock,
  Settings,
  Database,
  ArrowRight,
  Terminal,
  Rss,
} from 'lucide-react';
import { createClient } from '@/utils/supabase/client';
import type { User as SupabaseUser } from '@supabase/supabase-js';
import MovieCard, { RecommendedFilm } from '@/components/MovieCard';
import { useLetterboxdRssSync } from '@/hooks/useLetterboxdRssSync';
import { deduplicateWatchlist } from '@/lib/deduplication';
import { pickLetterboxdHandle } from '@/lib/letterboxdRss';
import { clearClientStorage, downloadRatingsCsv, withTimeout, type CsvDownloadResult } from '@/lib/vaultStorage';

// Initial Sample Masterpiece Cohort
const INITIAL_MASTERPIECE_COHORT: RecommendedFilm[] = [
  {
    id: 'memories-of-murder-2003',
    title: 'Memories of Murder',
    originalTitle: '살인의 추억',
    year: 2003,
    runtime: '131 min',
    country: 'South Korea',
    countryFlag: '🇰🇷',
    director: 'Bong Joon-ho',
    imdbRating: '8.1',
    letterboxdRating: '4.3',
    posterUrl: '',
    matchScore: '99.4%',
    obscurityBadge: 'Tier 4 // Masterpiece Cohort',
    obscurityLevel: 4,
    streamingPlatforms: ['Prime Video', 'MUBI', 'Criterion Channel'],
    whereToWatchInIndia: ['Prime Video India', 'MUBI India', 'Apple TV (Rent/Buy)'],
    contentAdvisory: 'Psychological Tension & Grim Investigation Procedures',
    synopsis:
      "In a rural Korean province in 1986, two vastly mismatched detectives struggle with crude methodology and obsessive desperation while hunting South Korea's first recorded serial murderer.",
    curatorialReason:
      "Matches your high rating for Bong Joon-ho's razor-sharp pacing, rain-soaked chiaroscuro cinematography, and moral ambiguity seen in Zodiac and Parasite.",
    trailerUrl: 'https://www.youtube.com/results?search_query=Memories+of+Murder+2003+official+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/memories-of-murder/',
  },
  {
    id: 'cure-1997',
    title: 'Cure',
    originalTitle: 'キュア',
    year: 1997,
    runtime: '111 min',
    country: 'Japan',
    countryFlag: '🇯🇵',
    director: 'Kiyoshi Kurosawa',
    imdbRating: '7.5',
    letterboxdRating: '4.1',
    posterUrl: '',
    matchScore: '98.9%',
    obscurityBadge: 'Tier 4 // Masterpiece Cohort',
    obscurityLevel: 4,
    streamingPlatforms: ['Criterion Channel', 'Apple TV'],
    whereToWatchInIndia: ['MUBI India', 'Apple TV Store India', 'Criterion Channel (VPN)'],
    contentAdvisory: 'Hypnotic Psychological Thriller & Existential Dread',
    synopsis:
      'A detective investigates a string of bizarre, gruesome murders committed by ordinary citizens who retain no recollection of their deeds after encountering an enigmatic amnesiac wanderer.',
    curatorialReason:
      'Clinical detachment, creeping dread, hypnotic soundscapes, and existential terror perfectly aligned with your psychological neo-noir taste vector.',
    trailerUrl: 'https://www.youtube.com/results?search_query=Cure+1997+Kiyoshi+Kurosawa+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/cure/',
  },
  {
    id: 'burning-2018',
    title: 'Burning',
    originalTitle: '버닝',
    year: 2018,
    runtime: '148 min',
    country: 'South Korea',
    countryFlag: '🇰🇷',
    director: 'Lee Chang-dong',
    imdbRating: '7.5',
    letterboxdRating: '4.0',
    posterUrl: '',
    matchScore: '98.1%',
    obscurityBadge: 'Tier 4 // Masterpiece Cohort',
    obscurityLevel: 4,
    streamingPlatforms: ['Netflix', 'MUBI', 'Prime Video'],
    whereToWatchInIndia: ['Prime Video India', 'MUBI India', 'Netflix India'],
    contentAdvisory: 'Slow-burn Atmospheric Tension & Ambiguous Enigma',
    synopsis:
      'An aspiring young writer becomes entangled with an enigmatic acquaintance and a wealthy, charismatic man she meets on a trip, leading to an obsessive disappearance investigation.',
    curatorialReason:
      'Haruki Murakami adaptation echoing your high affinity for Drive My Car. Exceptional ambient natural lighting and subtle class friction.',
    trailerUrl: 'https://www.youtube.com/results?search_query=Burning+2018+Lee+Chang-dong+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/burning-2018/',
  },
];

// Initial Sample Excellent Gems Cohort
const INITIAL_EXCELLENT_COHORT: RecommendedFilm[] = [
  {
    id: 'possession-1981',
    title: 'Possession',
    originalTitle: 'Possession',
    year: 1981,
    runtime: '124 min',
    country: 'France / Germany',
    countryFlag: '🇫🇷',
    director: 'Andrzej Żuławski',
    imdbRating: '7.3',
    letterboxdRating: '4.2',
    posterUrl: '',
    matchScore: '97.2%',
    obscurityBadge: 'Tier 4 // Excellent Gem',
    obscurityLevel: 4,
    streamingPlatforms: ['Metrograph at Home', 'Shudder'],
    whereToWatchInIndia: ['MUBI India', 'Apple TV (VOD Rent)', 'Criterion Channel (VPN)'],
    contentAdvisory: 'Severe Psychological Hysteria & Surrealist Body Horror',
    synopsis:
      'Set against the Cold War backdrop of the Berlin Wall, an intelligence spy returns home to his unraveling marriage only to discover his wife has formed an unspeakable metaphysical liaison.',
    curatorialReason:
      'Synthesized from your high affinity for visceral body horror, unhinged dual performances, and intense existential allegories.',
    trailerUrl: 'https://www.youtube.com/results?search_query=Possession+1981+Zulawski+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/possession-1981/',
  },
  {
    id: 'on-the-silver-globe-1988',
    title: 'On the Silver Globe',
    originalTitle: 'Na srebrnym globie',
    year: 1988,
    runtime: '166 min',
    country: 'Poland',
    countryFlag: '🇵🇱',
    director: 'Andrzej Żuławski',
    imdbRating: '7.2',
    letterboxdRating: '4.0',
    posterUrl: '',
    matchScore: '96.5%',
    obscurityBadge: 'Tier 4 // Excellent Gem',
    obscurityLevel: 4,
    streamingPlatforms: ['Eastern Promises', 'Kino Lorber Cult'],
    whereToWatchInIndia: ['Eastern Promises India', 'MUBI India', 'Archival 4K / YouTube Cinema'],
    contentAdvisory: 'Hallucinatory Sci-Fi Metaphysics & Pagan Savagery',
    synopsis:
      'Astronauts crash-land on an alien world and establish a primal society that gradually devolves into religious mythology, tribal wars, and pagan savagery over subsequent generations.',
    curatorialReason:
      'A restored Polish science fiction odyssey that pushed European cinema to its absolute ecstatic, philosophical limits.',
    trailerUrl: 'https://www.youtube.com/results?search_query=On+the+Silver+Globe+1988+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/on-the-silver-globe/',
  },
];

// ---------------------------------------------------------------------------
// Constants & strictly-typed helpers
// ---------------------------------------------------------------------------

type DashboardPhase = 'authenticating' | 'loading-vault' | 'ready' | 'error';

const AUTH_TIMEOUT_MS = 12_000;
const STORAGE_TIMEOUT_MS = 15_000;

const DEFAULT_TASTE_PROFILE =
  'Synthesized from high weights in non-linear chronology, rain-drenched chiaroscuro lighting, and morally gray investigator tropes.';
const DEFAULT_TASTE_TAGS: readonly string[] = [
  'Neo-Noir Chiaroscuro',
  'Atmospheric Dread',
  'Slow-Burn Paranoia',
  'Auteur Psychology',
];
const DEFAULT_WATCHLIST_IDS: readonly string[] = ['memories-of-murder-2003'];
const DEFAULT_VIBES: readonly string[] = ['🧠 Mind-Bending', '🔪 Dark Thriller', '🤯 Mind Twist'];
const DEFAULT_INDIA_STREAMING: readonly string[] = ['MUBI India', 'Prime Video India', 'Apple TV (Rent/Buy)'];

type JsonRecord = Record<string, unknown>;

function isRecord(value: unknown): value is JsonRecord {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function asText(value: unknown): string {
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  return '';
}

function firstText(...values: unknown[]): string {
  for (const v of values) {
    const t = asText(v);
    if (t) return t;
  }
  return '';
}

function textList(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(asText).filter((s) => s.length > 0);
  if (typeof value === 'string') return value.split(',').map((s) => s.trim()).filter((s) => s.length > 0);
  return [];
}

function slugify(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-');
}

/** Signed-out detection that does not depend on auth-js exporting its error guards. */
function isSignedOutError(error: unknown): boolean {
  if (!isRecord(error)) return false;
  return error.name === 'AuthSessionMissingError' || error.status === 401 || error.status === 403;
}

function errorText(error: unknown, fallback: string): string {
  return error instanceof Error && error.message ? error.message : fallback;
}

/** Maps one untrusted AI/API film payload to the strict RecommendedFilm shape. */
function mapRecommendedFilm(
  f: JsonRecord,
  idx: number,
  isMasterpiece: boolean,
  obscurityLevel: number
): RecommendedFilm {
  const title = firstText(f.title) || 'Curated Feature';

  const streaming =
    [f.whereToWatchInIndia, f.where_to_watch_india, f.streamingPlatforms]
      .map(textList)
      .find((list) => list.length > 0) ?? [...DEFAULT_INDIA_STREAMING];

  const imdbRaw = Number(firstText(f.imdb_rating, f.imdbRating));
  const imdb = Number.isFinite(imdbRaw) && imdbRaw > 0 ? imdbRaw : 7.8;
  const yearRaw = Number(firstText(f.year));
  const advisory =
    firstText(f.content_advisory, f.contentAdvisory, f.advisory) || 'Psychological tension & atmospheric immersion';

  return {
    id: firstText(f.id) || `rec-${isMasterpiece ? 'm' : 'e'}-${idx}-${slugify(title === 'Curated Feature' ? 'film' : title)}`,
    title,
    originalTitle: firstText(f.originalTitle) || title,
    year: Number.isFinite(yearRaw) && yearRaw > 0 ? yearRaw : 2020,
    runtime: firstText(f.runtime) || (firstText(f.runtime_mins) ? `${firstText(f.runtime_mins)} min` : '120 min'),
    country: firstText(f.country) || 'International',
    countryFlag: firstText(f.countryFlag) || '🌐',
    director: firstText(f.director) || (isMasterpiece ? 'Visionary Auteur' : 'Underground Auteur'),
    imdbRating: `${firstText(f.imdb_rating, f.imdbRating) || '7.8'}`,
    letterboxdRating: firstText(f.letterboxdRating) || Math.min(5.0, imdb / 2 + 0.3).toFixed(1),
    posterUrl: '',
    matchScore: firstText(f.matchScore) || `${isMasterpiece ? (99.4 - idx * 0.5).toFixed(1) : (97.2 - idx * 0.7).toFixed(1)}%`,
    obscurityBadge:
      firstText(f.obscurityBadge) || `Tier ${obscurityLevel} // ${isMasterpiece ? 'Masterpiece Cohort' : 'Excellent Gem'}`,
    obscurityLevel,
    streamingPlatforms: streaming,
    whereToWatchInIndia: streaming,
    contentAdvisory: advisory,
    advisory,
    synopsis:
      firstText(f.spoiler_free_premise, f.synopsis) || 'A singular cinematic meditation challenging conventional narrative constraints.',
    curatorialReason: firstText(f.thematic_alignment, f.curatorialReason) || 'Matches your high affinity for deep auteur storytelling.',
    trailerUrl:
      firstText(f.trailerUrl) ||
      `https://www.youtube.com/results?search_query=${encodeURIComponent(`${firstText(f.title)} official trailer`)}`,
    letterboxdUrl: firstText(f.letterboxdUrl) || `https://letterboxd.com/film/${encodeURIComponent(slugify(firstText(f.title)))}/`,
  };
}

export default function DashboardPage() {
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);

  // ---- Auth & hydration state machine --------------------------------------
  // authenticating -> loading-vault -> ready   (or -> error with Retry)
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [phase, setPhase] = useState<DashboardPhase>('authenticating');
  const [initError, setInitError] = useState<string | null>(null);
  const [authEpoch, setAuthEpoch] = useState<number>(0);
  const [profileUsername, setProfileUsername] = useState<string>('');
  const [isSigningOut, setIsSigningOut] = useState<boolean>(false);

  const currentUserIdRef = useRef<string | null>(null);
  const signingOutRef = useRef<boolean>(false);

  // ---- Storage state ---------------------------------------------------------
  const [hasSavedCsv, setHasSavedCsv] = useState<boolean>(false);
  const [uniqueMovieCount, setUniqueMovieCount] = useState<number | null>(null);
  const [vaultReadFailed, setVaultReadFailed] = useState<boolean>(false);

  const isLoading = phase === 'authenticating';
  const fetchingStatus = phase === 'authenticating' || phase === 'loading-vault';

  // ---- Silent RSS sync: inert until auth + vault load have fully resolved -----
  const {
    isSyncing: isSyncingRss,
    syncedCount: rssSyncedCount,
    username: syncedUsername,
    lastSyncedAt: rssLastSyncedAt,
    wroteStorage: rssWroteStorage,
    error: rssError,
    triggerSync,
    reset: resetRssSync,
  } = useLetterboxdRssSync({
    userId: phase === 'ready' && user ? user.id : null,
    handle: profileUsername,
  });

  // ---- Filter & curatorial tuning state ---------------------------------------
  const [obscurityLevel, setObscurityLevel] = useState<number>(4);
  const [isFamilySafe, setIsFamilySafe] = useState<boolean>(false);
  const [selectedVibes, setSelectedVibes] = useState<string[]>([...DEFAULT_VIBES]);
  const [runtimeFilter, setRuntimeFilter] = useState<'any' | '<90' | '<=120' | '140+'>('<=120');

  // ---- Cohort feed state --------------------------------------------------------
  const [activeCohortTab, setActiveCohortTab] = useState<'masterpiece' | 'excellent' | 'all'>('masterpiece');
  const [sortBy, setSortBy] = useState<'affinity' | 'year' | 'rating'>('affinity');
  const [masterpieceCohort, setMasterpieceCohort] = useState<RecommendedFilm[]>(INITIAL_MASTERPIECE_COHORT);
  const [excellentCohort, setExcellentCohort] = useState<RecommendedFilm[]>(INITIAL_EXCELLENT_COHORT);
  const [tasteProfile, setTasteProfile] = useState<string>(DEFAULT_TASTE_PROFILE);
  const [tasteProfileSummary, setTasteProfileSummary] = useState<string>(DEFAULT_TASTE_PROFILE);
  const [tasteDnaTags, setTasteDnaTags] = useState<string[]>([...DEFAULT_TASTE_TAGS]);

  // ---- Watchlist & trailer -------------------------------------------------------
  const [watchlistIds, setWatchlistIds] = useState<string[]>([...DEFAULT_WATCHLIST_IDS]);
  const [activeTrailerFilm, setActiveTrailerFilm] = useState<RecommendedFilm | null>(null);

  // ---- Visual mobile debugger state ------------------------------------------------
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [liveExecutionStep, setLiveExecutionStep] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedError, setCopiedError] = useState(false);
  const [aiNotice, setAiNotice] = useState<string | null>(null);

  // ---- Derived handles (display only; sync uses the validated profile handle) --------
  const userEmail = user?.email || 'curator@cultcrate.vault';
  const letterboxdHandle =
    profileUsername ||
    syncedUsername ||
    (typeof user?.user_metadata?.letterboxd_username === 'string' ? user.user_metadata.letterboxd_username : '') ||
    user?.email?.split('@')[0] ||
    'cinephile_curator';

  // ===========================================================================
  // CLEAN RESET: every piece of per-user state returns to its pristine value so
  // nothing from a previous session can leak into the next login.
  // ===========================================================================
  const resetDashboardState = useCallback(() => {
    currentUserIdRef.current = null;
    setUser(null);
    setProfileUsername('');
    setHasSavedCsv(false);
    setUniqueMovieCount(null);
    setVaultReadFailed(false);
    setInitError(null);
    setErrorMessage(null);
    setAiNotice(null);
    setLiveExecutionStep(null);
    setIsSynthesizing(false);
    setCopiedError(false);
    setMasterpieceCohort(INITIAL_MASTERPIECE_COHORT);
    setExcellentCohort(INITIAL_EXCELLENT_COHORT);
    setTasteProfile(DEFAULT_TASTE_PROFILE);
    setTasteProfileSummary(DEFAULT_TASTE_PROFILE);
    setTasteDnaTags([...DEFAULT_TASTE_TAGS]);
    setWatchlistIds([...DEFAULT_WATCHLIST_IDS]);
    setActiveTrailerFilm(null);
    resetRssSync();
  }, [resetRssSync]);

  const applyCsvResult = useCallback((result: CsvDownloadResult) => {
    if (result.status === 'found') {
      const { totalWatchedCount } = deduplicateWatchlist(result.text, null);
      setHasSavedCsv(totalWatchedCount > 0);
      setUniqueMovieCount(totalWatchedCount);
      setVaultReadFailed(false);
    } else if (result.status === 'missing') {
      setHasSavedCsv(false);
      setUniqueMovieCount(null);
      setVaultReadFailed(false);
    } else {
      // Never present a failed download as "0 films"
      setVaultReadFailed(true);
      setErrorMessage(`Could not read ratings.csv from your vault: ${result.message}`);
    }
  }, []);

  // ===========================================================================
  // AUTH-FIRST INITIALIZER
  // 1. supabase.auth.getUser() fully resolves   (nothing else runs before it)
  // 2. registered handle is read
  // 3. ratings.csv is downloaded with every cache layer bypassed
  // 4. only then does phase become 'ready', which is what arms the RSS sync
  // Every await has a timeout and the effect is cancellation-safe, so the UI can
  // neither hang forever nor apply stale results from a previous run/account.
  // ===========================================================================
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();

    const redirectToAuth = async (): Promise<void> => {
      // Drop any stale local session first, otherwise middleware would bounce /auth -> /dashboard
      try {
        await supabase.auth.signOut({ scope: 'local' });
      } catch {
        /* nothing to clear */
      }
      if (!cancelled) router.replace('/auth');
    };

    const init = async (): Promise<void> => {
      setPhase('authenticating');
      setInitError(null);
      setErrorMessage(null);

      // STEP 1: resolve the authenticated user COMPLETELY
      let currentUser: SupabaseUser | null = null;
      try {
        const { data, error } = await withTimeout(supabase.auth.getUser(), AUTH_TIMEOUT_MS, 'Authentication check');
        if (cancelled) return;
        if (error) {
          if (isSignedOutError(error)) {
            await redirectToAuth();
            return;
          }
          throw error;
        }
        currentUser = data.user;
      } catch (err: unknown) {
        if (cancelled) return;
        console.error('[Dashboard] auth check failed:', err);
        setInitError(errorText(err, 'Could not verify your session.'));
        setPhase('error');
        return;
      }

      if (!currentUser) {
        await redirectToAuth();
        return;
      }

      currentUserIdRef.current = currentUser.id;
      setUser(currentUser);
      setPhase('loading-vault');

      // STEP 2: registered Letterboxd handle (select('*') so a missing column cannot error the query)
      let handle = '';
      try {
        const { data: profileRow } = await supabase.from('profiles').select('*').eq('id', currentUser.id).maybeSingle();
        const profile: JsonRecord = isRecord(profileRow) ? profileRow : {};
        const metadata: JsonRecord = isRecord(currentUser.user_metadata) ? currentUser.user_metadata : {};
        handle = pickLetterboxdHandle(profile.letterboxd_username, metadata.letterboxd_username);
      } catch (err: unknown) {
        console.warn('[Dashboard] profile lookup failed, continuing without handle:', err);
      }
      if (cancelled) return;
      setProfileUsername(handle);

      // STEP 3: ratings.csv from Supabase Storage (no-store + cacheNonce)
      try {
        const result = await withTimeout(
          downloadRatingsCsv(supabase, currentUser.id, { signal: controller.signal }),
          STORAGE_TIMEOUT_MS,
          'Vault download'
        );
        if (cancelled) return;
        applyCsvResult(result);
      } catch (err: unknown) {
        if (cancelled) return;
        setVaultReadFailed(true);
        setErrorMessage(`Could not read ratings.csv from your vault: ${errorText(err, 'unknown error')}`);
      }

      if (!cancelled) setPhase('ready');
    };

    void init();

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [supabase, router, authEpoch, applyCsvResult]);

  // Account switches / sign-outs that happen outside this component (other tab, expiry)
  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      // NOTE: no awaited supabase calls in here (known auth-js deadlock); only schedule state changes.
      if (signingOutRef.current) return;

      if (event === 'SIGNED_OUT') {
        resetDashboardState();
        router.replace('/auth');
        return;
      }

      const knownId = currentUserIdRef.current;
      if (event === 'SIGNED_IN' && session?.user && knownId !== null && session.user.id !== knownId) {
        resetDashboardState();
        setAuthEpoch((n) => n + 1);
      }
    });

    return () => subscription.unsubscribe();
  }, [supabase, router, resetDashboardState]);

  // After a sync that rewrote ratings.csv, re-read it so the sidebar mirrors Storage exactly
  useEffect(() => {
    if (phase !== 'ready' || !user || !rssLastSyncedAt || !rssWroteStorage) return;
    let cancelled = false;
    const userId = user.id;

    void (async () => {
      const result = await downloadRatingsCsv(supabase, userId);
      if (!cancelled && currentUserIdRef.current === userId) applyCsvResult(result);
    })();

    return () => {
      cancelled = true;
    };
  }, [supabase, phase, user, rssLastSyncedAt, rssWroteStorage, applyCsvResult]);

  const retryInit = useCallback(() => {
    setErrorMessage(null);
    setAuthEpoch((n) => n + 1);
  }, []);

  // Derived unique count incorporating the live RSS merge result
  const displayWatchedCount = useMemo(() => {
    if (rssSyncedCount !== null && rssSyncedCount > 0) {
      return uniqueMovieCount !== null ? Math.max(uniqueMovieCount, rssSyncedCount) : rssSyncedCount;
    }
    return uniqueMovieCount;
  }, [uniqueMovieCount, rssSyncedCount]);

  // ===========================================================================
  // SIGN OUT: revoke first (needs the refresh token), THEN wipe everything.
  // Clearing storage before signOut() destroyed the token and left the auth
  // cookie behind, the root of the "logged out but not really" deadlock.
  // ===========================================================================
  const handleSignOut = async (): Promise<void> => {
    if (signingOutRef.current) return;
    signingOutRef.current = true;
    setIsSigningOut(true);

    try {
      const { error } = await supabase.auth.signOut();
      if (error) await supabase.auth.signOut({ scope: 'local' });
    } catch (err: unknown) {
      console.warn('[Dashboard] global sign-out failed, falling back to local:', err);
      try {
        await supabase.auth.signOut({ scope: 'local' });
      } catch {
        /* session already gone */
      }
    }

    resetDashboardState();
    clearClientStorage();
    router.replace('/auth');
    router.refresh();
  };

  // ===========================================================================
  // RUN CULTCRATE AI ENGINE
  // ===========================================================================
  const handleRunCultCrateAI = async (): Promise<void> => {
    if (!user) return;
    setIsSynthesizing(true);
    setErrorMessage(null);

    try {
      const preferenceTags = [
        ...selectedVibes,
        isFamilySafe ? 'Family-Friendly / No Extreme Content' : 'Unfiltered Arthouse',
        `Runtime Aperture: ${runtimeFilter}`,
      ];

      // Make sure ratings.csv is fresh BEFORE the engine reads it (previously fire-and-forget + 200ms sleep)
      setLiveExecutionStep('Syncing live Letterboxd feed & deduplicating...');
      await triggerSync();

      setLiveExecutionStep('Sending deduplicated payload to Gemini...');
      const {
        data: { session },
      } = await supabase.auth.getSession();
      const sessionToken = session?.access_token;

      const response = await fetch('/api/recommendations', {
        method: 'POST',
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/json',
          ...(sessionToken ? { Authorization: `Bearer ${sessionToken}` } : {}),
        },
        body: JSON.stringify({
          username: profileUsername || undefined,
          obscurityLevel,
          preferences: preferenceTags,
        }),
      });

      setLiveExecutionStep('Received response. Synthesizing recommendations...');

      if (!response.ok) {
        let exactErrorMessage = `Recommendations endpoint returned HTTP status ${response.status}`;
        const raw = await response.text().catch(() => '');
        try {
          const parsed: unknown = JSON.parse(raw);
          if (isRecord(parsed)) {
            exactErrorMessage = firstText(parsed.error, parsed.message) || exactErrorMessage;
          }
        } catch {
          if (raw) exactErrorMessage = raw;
        }
        throw new Error(exactErrorMessage);
      }

      const data: unknown = await response.json().catch(() => null);
      if (!isRecord(data)) {
        throw new Error('Malformed or empty JSON payload returned by CultCrate AI.');
      }

      const dedupCount = Number(data.watchedDeduplicationCount);
      if (Number.isFinite(dedupCount) && dedupCount > 0) {
        setUniqueMovieCount(dedupCount);
      }

      const summary = firstText(data.taste_profile_summary, data.tasteProfileSummary, data.tasteProfile);
      if (summary) {
        setTasteProfile(summary);
        setTasteProfileSummary(summary);
      }

      const tags = textList(data.tasteDnaTags);
      if (tags.length > 0) setTasteDnaTags(tags);

      const toFilms = (raw: unknown, isMasterpiece: boolean): RecommendedFilm[] =>
        Array.isArray(raw)
          ? raw.filter(isRecord).map((f, i) => mapRecommendedFilm(f, i, isMasterpiece, obscurityLevel))
          : [];

      const masterpiece = toFilms(data.masterpiece_cohort ?? data.masterpieceCohort, true);
      const excellent = toFilms(data.excellent_cohort ?? data.excellentCohort, false);
      if (masterpiece.length > 0) setMasterpieceCohort(masterpiece);
      if (excellent.length > 0) setExcellentCohort(excellent);

      setAiNotice(`CultCrate AI successfully curated cohorts for @${letterboxdHandle}!`);
      setLiveExecutionStep(null);
    } catch (err: unknown) {
      console.error('Synthesis error:', err);
      setErrorMessage(err instanceof Error ? err.message : String(err));
      setLiveExecutionStep(null);
    } finally {
      setIsSynthesizing(false);
    }
  };

  // Safe cohort list derived from state
  const displayedFilms = useMemo(() => {
    const safeMasterpiece = Array.isArray(masterpieceCohort) ? masterpieceCohort : [];
    const safeExcellent = Array.isArray(excellentCohort) ? excellentCohort : [];

    const list: RecommendedFilm[] =
      activeCohortTab === 'masterpiece'
        ? [...safeMasterpiece]
        : activeCohortTab === 'excellent'
        ? [...safeExcellent]
        : [...safeMasterpiece, ...safeExcellent];

    const num = (v: unknown): number => {
      const n = parseFloat(String(v ?? '0'));
      return Number.isFinite(n) ? n : 0;
    };

    if (sortBy === 'affinity') {
      list.sort((a, b) => num(b.matchScore) - num(a.matchScore));
    } else if (sortBy === 'year') {
      list.sort((a, b) => num(b.year) - num(a.year));
    } else {
      list.sort((a, b) => num(b.letterboxdRating) - num(a.letterboxdRating));
    }

    return list;
  }, [activeCohortTab, masterpieceCohort, excellentCohort, sortBy]);

  const toggleWatchlist = (id: string): void => {
    setWatchlistIds((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
  };

  const handleCopyError = (): void => {
    if (errorMessage && typeof navigator !== 'undefined' && navigator.clipboard) {
      void navigator.clipboard.writeText(errorMessage).then(() => {
        setCopiedError(true);
        setTimeout(() => setCopiedError(false), 2000);
      });
    }
  };

  // Could not even verify the session (network / timeout): offer a retry instead of a dead end
  if (phase === 'error' && !user) {
    return (
      <div className="min-h-screen bg-[#090D16] flex flex-col items-center justify-center font-sans text-white p-4">
        <div className="flex flex-col items-center gap-4 max-w-sm text-center">
          <div className="w-12 h-12 rounded-2xl bg-[#1a080a] border-2 border-[#E50914] flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-[#E50914]" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-bold tracking-wider font-mono uppercase">Could not verify your session</h3>
            <p className="text-xs text-[#9CA3AF] font-mono break-words">{initError ?? 'Unknown error'}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={retryInit}
              className="px-4 py-2 rounded-xl bg-[#E50914] hover:bg-[#B80710] text-xs font-bold font-mono flex items-center gap-2 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
            <Link
              href="/auth"
              className="px-4 py-2 rounded-xl bg-[#121620] border border-[#232936] text-xs font-mono text-[#9CA3AF] hover:text-white"
            >
              Sign in again
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#090D16] flex flex-col items-center justify-center font-sans text-white p-4">
        <div className="flex flex-col items-center gap-4 max-w-sm text-center">
          <div className="relative w-12 h-12 rounded-2xl bg-[#E50914] flex items-center justify-center animate-pulse shadow-[0_0_35px_rgba(229,9,20,0.6)]">
            <Film className="w-6 h-6 text-white" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-bold tracking-wider font-mono text-white uppercase">
              Verifying Screening Vault...
            </h3>
            <p className="text-xs text-[#9CA3AF] font-mono">
              Synchronizing Supabase ratings.csv &amp; Letterboxd RSS feed
            </p>
          </div>
          <div className="w-48 h-1 bg-[#121620] rounded-full overflow-hidden border border-[#232936] mt-2">
            <div className="w-full h-full bg-[#E50914] animate-pulse rounded-full" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#090D16] text-[#F9FAFB] font-sans selection:bg-[#E50914] selection:text-white pb-24 overflow-x-hidden">
      {/* Background Glows */}
      <div className="fixed top-20 left-1/3 w-[500px] h-[500px] bg-[#E50914]/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="fixed top-1/2 -right-20 w-[400px] h-[400px] bg-[#F59E0B]/5 rounded-full blur-[120px] pointer-events-none -z-10" />

      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#090D16]/90 backdrop-blur-xl border-b border-[#232936] px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 group">
          <div className="relative w-9 h-9 rounded-xl bg-gradient-to-br from-[#E50914] to-[#900008] flex items-center justify-center shadow-lg shadow-[#E50914]/30 group-hover:scale-105 transition-transform duration-200">
            <Film className="w-5 h-5 text-white" />
            <div className="absolute inset-0 rounded-xl bg-[#E50914] blur-sm opacity-40 group-hover:opacity-75 transition-opacity" />
          </div>

          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight text-white leading-none">
              Cult<span className="text-[#E50914]">Crate</span>
            </span>
            <span className="text-[10px] font-mono tracking-wider text-[#9CA3AF] uppercase mt-0.5">
              Screening Dashboard // Vault
            </span>
          </div>
        </Link>

        {/* User Info */}
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-[#121620] border border-[#232936] text-xs font-mono">
            <div className="w-2 h-2 rounded-full bg-[#4EDEAE] animate-pulse" />
            <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2 leading-none">
              <span className="text-white font-semibold">@{letterboxdHandle}</span>
              <span className="hidden md:inline text-[#9CA3AF] text-[11px]">({userEmail})</span>
            </div>
          </div>

          <Link
            href="/settings"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#121620] hover:bg-[#1c2230] border border-[#232936] hover:border-[#E50914]/50 text-xs font-mono text-[#9CA3AF] hover:text-white transition-all cursor-pointer active:scale-95"
            title="Configure Settings"
          >
            <Settings className="w-3.5 h-3.5 text-zinc-400 group-hover:text-white" />
            <span className="hidden sm:inline">Settings</span>
          </Link>

          <button
            onClick={handleSignOut}
            disabled={isSigningOut}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#121620] hover:bg-[#1c2230] border border-[#232936] hover:border-[#E50914]/50 text-xs font-mono text-[#9CA3AF] hover:text-white transition-all cursor-pointer active:scale-95"
            title="Log out"
          >
            <LogOut className="w-3.5 h-3.5 text-[#E50914]" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
        {/* Error Notification */}
        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.99 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="p-5 rounded-2xl bg-[#1a080a] border-2 border-[#E50914] text-red-100 shadow-[0_0_35px_rgba(229,9,20,0.4)] space-y-3"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#E50914] flex items-center justify-center shrink-0 shadow-[0_0_15px_#E50914]">
                  <XCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                    Curatorial Engine Error
                  </h3>
                  <p className="text-[11px] text-red-300 font-mono">
                    Exact server error message:
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {vaultReadFailed && (
                  <button
                    type="button"
                    onClick={retryInit}
                    className="px-3 py-1.5 rounded-lg bg-black/60 hover:bg-black text-xs font-mono text-red-200 hover:text-white border border-red-500/40 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Retry</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleCopyError}
                  className="px-3 py-1.5 rounded-lg bg-black/60 hover:bg-black text-xs font-mono text-red-200 hover:text-white border border-red-500/40 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedError ? <Check className="w-3.5 h-3.5 text-[#4EDEAE]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedError ? 'Copied!' : 'Copy Error'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setErrorMessage(null)}
                  className="p-1.5 rounded-lg bg-black/60 hover:bg-black text-red-300 hover:text-white border border-red-500/40 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-black/80 border border-red-500/50 font-mono text-xs text-red-200 break-all select-all leading-relaxed max-h-48 overflow-y-auto">
              <pre className="whitespace-pre-wrap font-mono text-xs">{errorMessage}</pre>
            </div>
          </motion.div>
        )}

        {/* AI Notice */}
        {aiNotice && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-3.5 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center justify-between gap-2 shadow-[0_0_20px_rgba(78,222,174,0.15)]"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#4EDEAE] shrink-0" />
              <span>{aiNotice}</span>
            </div>
            <button
              onClick={() => setAiNotice(null)}
              className="text-emerald-400 hover:text-white text-xs cursor-pointer"
            >
              ✕
            </button>
          </motion.div>
        )}

        {/* Sidebar & Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* LEFT SIDEBAR: Storage & Deduplication Telemetry */}
          <aside className="lg:col-span-4 space-y-6 lg:sticky lg:top-24">
            <div className="rounded-2xl bg-[#121620]/90 border border-[#232936] p-6 backdrop-blur-xl shadow-xl space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-[#232936]">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-[#E50914]" />
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                    Screening Vault Storage
                  </h2>
                </div>

                {fetchingStatus ? (
                  <span className="font-mono text-[10px] text-zinc-400 bg-[#121620] px-2.5 py-1 rounded-full border border-[#232936] flex items-center gap-1.5 animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-zinc-400" />
                    <span>Checking Vault...</span>
                  </span>
                ) : hasSavedCsv || (rssSyncedCount && rssSyncedCount > 0) ? (
                  <span className="font-mono text-[10px] text-[#4EDEAE] bg-[#4EDEAE]/15 px-2.5 py-1 rounded-full border border-[#4EDEAE]/40 flex items-center gap-1.5 shadow-[0_0_12px_rgba(78,222,174,0.2)]">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#4EDEAE] animate-pulse" />
                    <span className="font-semibold">Synced</span>
                  </span>
                ) : (
                  <span className="font-mono text-[10px] text-[#F59E0B] bg-[#F59E0B]/10 px-2 py-0.5 rounded border border-[#F59E0B]/30">
                    Awaiting Ratings
                  </span>
                )}
              </div>

              {/* Silent RSS Background Status Bar */}
              <div className="p-3 rounded-xl bg-[#090D16] border border-[#232936] flex items-center justify-between gap-2 font-mono text-xs">
                <div className="flex items-center gap-2 truncate">
                  <Rss className={`w-3.5 h-3.5 text-[#E50914] ${isSyncingRss ? 'animate-pulse' : ''}`} />
                  <div className="flex flex-col truncate">
                    <span className="text-[10px] text-[#9CA3AF] uppercase">Deduplication Pipeline</span>
                    <span className="text-xs font-semibold text-white truncate">
                      {isSyncingRss
                        ? 'Syncing live feed...'
                        : rssError
                        ? `Sync issue: ${rssError}`
                        : rssSyncedCount !== null
                        ? `Live RSS Synced (${rssSyncedCount} items)`
                        : `Pipeline Active (@${letterboxdHandle})`}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => void triggerSync()}
                  disabled={isSyncingRss}
                  className="px-2.5 py-1 rounded bg-[#121620] hover:bg-[#1a202c] border border-[#232936] text-[10px] text-[#4EDEAE] hover:text-white flex items-center gap-1 transition-colors cursor-pointer shrink-0 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${isSyncingRss ? 'animate-spin' : ''}`} />
                  <span>Sync</span>
                </button>
              </div>

              {/* Storage Status Active/Warning Block */}
              {fetchingStatus ? (
                <div className="p-4 rounded-xl bg-[#090D16] border border-[#232936] animate-pulse flex items-center gap-3 font-mono text-xs">
                  <div className="w-9 h-9 rounded-xl bg-[#232936] shrink-0" />
                  <div className="space-y-2 flex-1">
                    <div className="h-3 bg-[#232936] rounded w-2/3" />
                    <div className="h-2.5 bg-[#232936] rounded w-1/2" />
                  </div>
                </div>
              ) : hasSavedCsv || (rssSyncedCount && rssSyncedCount > 0) ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 rounded-xl bg-emerald-950/50 border border-[#4EDEAE]/50 text-emerald-100 font-mono text-xs flex items-center justify-between gap-3 shadow-[0_0_20px_rgba(78,222,174,0.15)]"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-[#4EDEAE]/15 border border-[#4EDEAE]/30 flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-5 h-5 text-[#4EDEAE]" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-[#4EDEAE] animate-pulse shadow-[0_0_8px_#4EDEAE]" />
                        <span className="font-bold text-white tracking-wide text-xs">
                          ratings.csv Active &amp; Synced
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-300 mt-0.5">
                        <code className="text-[#4EDEAE]">watchlists/{user?.id}/ratings.csv</code>
                      </p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold text-emerald-400 bg-emerald-900/50 border border-emerald-500/40 shrink-0">
                    Online
                  </span>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 rounded-xl bg-[#090D16] border border-amber-500/40 text-amber-200 font-mono text-xs space-y-3"
                >
                  <div className="flex items-start gap-2.5">
                    <AlertTriangle className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                    <p className="text-xs text-zinc-200 leading-relaxed">
                      No ratings.csv found. Upload your Letterboxd ratings.csv in Settings or sync your live RSS feed.
                    </p>
                  </div>
                  <Link
                    href="/settings"
                    className="w-full py-2.5 px-3 rounded-lg bg-[#E50914] hover:bg-[#b80710] text-white font-bold text-xs inline-flex items-center justify-center gap-2 transition-all shadow-[0_0_15px_rgba(229,9,20,0.4)]"
                  >
                    <span>Upload CSV in Settings</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </motion.div>
              )}

              {/* Total Unique Movies Metric */}
              <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-[#090D16] border border-[#232936] font-mono text-xs">
                <div>
                  <span className="text-[10px] text-[#9CA3AF] uppercase block">Unique Watched</span>
                  <span className="text-sm font-bold text-white truncate block mt-0.5">
                    {fetchingStatus ? (
                      <span className="inline-block w-16 h-4 bg-[#232936] rounded animate-pulse" />
                    ) : displayWatchedCount !== null && displayWatchedCount !== undefined ? (
                      `${displayWatchedCount} Unique Films`
                    ) : (
                      vaultReadFailed ? 'Unavailable' : '0 Films'
                    )}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-[#9CA3AF] uppercase block">Exclusion Array</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="w-2 h-2 rounded-full bg-[#4EDEAE] animate-pulse shadow-[0_0_8px_#4EDEAE]" />
                    <span className="font-semibold text-[11px] text-[#4EDEAE] truncate">
                      Zero Duplicates
                    </span>
                  </div>
                </div>
              </div>

              {/* Execution Step */}
              {liveExecutionStep && (
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3.5 rounded-xl bg-[#090D16] border border-[#E50914]/60 shadow-[0_0_20px_rgba(229,9,20,0.3)] space-y-1.5"
                >
                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <span className="text-[#E50914] font-bold flex items-center gap-1.5">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#E50914]" />
                      <span>Live Pipeline Status:</span>
                    </span>
                    <span className="text-[#4EDEAE] text-[10px] font-semibold animate-pulse">Running</span>
                  </div>
                  <p className="text-xs font-mono text-white font-semibold">
                    {liveExecutionStep}
                  </p>
                </motion.div>
              )}

              {/* Primary Action Button */}
              <button
                type="button"
                onClick={handleRunCultCrateAI}
                disabled={isSynthesizing}
                className="w-full py-4 px-4 rounded-xl bg-[#E50914] hover:bg-[#B80710] text-white text-sm font-bold tracking-wide transition-all duration-200 shadow-[0_0_30px_rgba(229,9,20,0.45)] hover:shadow-[0_0_45px_rgba(229,9,20,0.75)] flex items-center justify-center gap-2 disabled:opacity-75 disabled:cursor-not-allowed active:scale-[0.99] cursor-pointer"
              >
                {isSynthesizing ? (
                  <div className="flex items-center gap-2 font-mono text-xs">
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>{liveExecutionStep || 'Filtering & Deduplicating Taste Vectors...'}</span>
                  </div>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-white" />
                    <span>Run CultCrate AI Engine</span>
                  </>
                )}
              </button>
            </div>
          </aside>

          {/* RIGHT MAIN AREA */}
          <section className="lg:col-span-8 space-y-6">
            {/* Taste Profile Box */}
            <div className="rounded-2xl bg-gradient-to-r from-[#121620] via-[#121620] to-[#1a0e14] border border-[#232936] p-6 shadow-xl relative overflow-hidden space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Radio className="w-4 h-4 text-[#E50914] animate-pulse" />
                  <span className="font-mono text-xs text-[#E50914] font-bold uppercase tracking-wider">
                    Cinematic DNA &amp; Vector Space
                  </span>
                </div>
                <span className="font-mono text-[10px] text-[#4EDEAE] bg-[#4EDEAE]/10 border border-[#4EDEAE]/30 px-2 py-0.5 rounded">
                  Calibrated Tier {obscurityLevel}
                </span>
              </div>

              <p className="text-sm text-gray-200 leading-relaxed font-sans">
                {tasteProfile || tasteProfileSummary}
              </p>

              <div className="flex flex-wrap gap-1.5 pt-1">
                {tasteDnaTags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-0.5 rounded-md bg-[#090D16] border border-[#232936] font-mono text-[10px] text-[#9CA3AF] flex items-center gap-1"
                  >
                    <span>#</span>
                    <span>{tag}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Cohort Navigation & Sorter */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-2 rounded-xl bg-[#090D16] border border-[#232936]">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setActiveCohortTab('masterpiece')}
                  className={`px-3.5 py-2 rounded-lg font-mono text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                    activeCohortTab === 'masterpiece'
                      ? 'bg-[#E50914] text-white shadow-[0_0_15px_rgba(229,9,20,0.5)]'
                      : 'text-[#9CA3AF] hover:text-white hover:bg-[#121620]'
                  }`}
                >
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span>Masterpiece Cohort</span>
                  {Array.isArray(masterpieceCohort) && (
                    <span className="px-1.5 py-0.2 rounded bg-black/40 text-[10px]">
                      {masterpieceCohort.length}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCohortTab('excellent')}
                  className={`px-3.5 py-2 rounded-lg font-mono text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                    activeCohortTab === 'excellent'
                      ? 'bg-[#E50914] text-white shadow-[0_0_15px_rgba(229,9,20,0.5)]'
                      : 'text-[#9CA3AF] hover:text-white hover:bg-[#121620]'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Excellent Cohort</span>
                  {Array.isArray(excellentCohort) && (
                    <span className="px-1.5 py-0.2 rounded bg-black/40 text-[10px]">
                      {excellentCohort.length}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCohortTab('all')}
                  className={`px-3.5 py-2 rounded-lg font-mono text-xs font-semibold transition-all cursor-pointer ${
                    activeCohortTab === 'all'
                      ? 'bg-[#E50914] text-white shadow-[0_0_15px_rgba(229,9,20,0.5)]'
                      : 'text-[#9CA3AF] hover:text-white hover:bg-[#121620]'
                  }`}
                >
                  <span>All Curated</span>
                  {Array.isArray(masterpieceCohort) && Array.isArray(excellentCohort) && (
                    <span className="ml-1.5 px-1.5 py-0.2 rounded bg-black/40 text-[10px]">
                      {masterpieceCohort.length + excellentCohort.length}
                    </span>
                  )}
                </button>
              </div>

              <div className="flex items-center gap-2 font-mono text-xs px-2">
                <span className="text-[#9CA3AF] text-[11px] uppercase">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'affinity' | 'year' | 'rating')}
                  className="bg-[#121620] border border-[#232936] text-white text-xs rounded-lg px-2.5 py-1 focus:outline-none focus:border-[#E50914] cursor-pointer"
                >
                  <option value="affinity">Highest Affinity</option>
                  <option value="year">Release Year</option>
                  <option value="rating">Letterboxd Rating</option>
                </select>
              </div>
            </div>

            {/* Loading State */}
            {isSynthesizing && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="rounded-2xl bg-gradient-to-b from-[#121620] to-[#090D16] border-2 border-[#E50914]/40 p-8 sm:p-10 shadow-[0_0_50px_rgba(229,9,20,0.25)] relative overflow-hidden text-center space-y-6"
              >
                <div className="relative mx-auto w-20 h-20 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-2 border-dashed border-[#E50914] animate-[spin_6s_linear_infinite]" />
                  <div className="w-10 h-10 rounded-full bg-[#E50914] flex items-center justify-center shadow-[0_0_25px_#E50914]">
                    <Film className="w-5 h-5 text-white animate-pulse" />
                  </div>
                </div>

                <div className="space-y-2 relative z-10">
                  <span className="font-mono text-xs text-[#E50914] tracking-widest uppercase font-bold">
                    Neural Curatorial Matrix Active
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    Running Deduplication &amp; Curation Pipeline...
                  </h3>
                  <p className="text-xs text-[#9CA3AF] font-mono max-w-md mx-auto leading-relaxed">
                    {liveExecutionStep || `Cross-referencing Letterboxd records with Tier ${obscurityLevel} underground archives.`}
                  </p>
                </div>
              </motion.div>
            )}

            {/* Movie Cards */}
            {!isSynthesizing && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Array.isArray(displayedFilms) && displayedFilms.length > 0 ? (
                  displayedFilms.map((film) => (
                    <MovieCard
                      key={film.id}
                      movie={{
                        title: film.title,
                        year: film.year,
                        rating: film.letterboxdRating || film.imdbRating,
                        genre: Array.isArray(film.genre) ? film.genre.join(' • ') : (film.genre || 'Arthouse • Cult Cinema'),
                        reason: film.curatorialReason || film.synopsis,
                      }}
                      film={film}
                      isWatchlisted={watchlistIds.includes(film.id)}
                      onToggleWatchlist={toggleWatchlist}
                      onWatchTrailer={(f) => setActiveTrailerFilm(f)}
                    />
                  ))
                ) : (
                  <div className="p-12 text-center rounded-2xl bg-[#121620]/60 border border-[#232936] space-y-3 font-mono col-span-full">
                    <Film className="w-8 h-8 text-[#9CA3AF] mx-auto" />
                    <p className="text-sm text-gray-300 font-semibold">No films found in this cohort tab.</p>
                  </div>
                )}
              </div>
            )}
          </section>
        </div>
      </main>

      {/* Trailer Modal */}
      <AnimatePresence>
        {activeTrailerFilm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveTrailerFilm(null)}
              className="fixed inset-0 bg-black/85 backdrop-blur-md"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-2xl bg-[#121620] border border-[#232936] rounded-2xl p-6 shadow-[0_25px_60px_rgba(0,0,0,0.9),0_0_50px_rgba(229,9,20,0.25)] z-10"
            >
              <div className="flex items-start justify-between pb-4 border-b border-[#232936]">
                <div>
                  <span className="font-mono text-[10px] text-[#E50914] uppercase tracking-wider font-bold">
                    Official Screening Trailer
                  </span>
                  <h3 className="text-xl font-bold text-white mt-0.5">
                    {activeTrailerFilm.title} ({activeTrailerFilm.year})
                  </h3>
                  <p className="text-xs text-[#9CA3AF] font-mono">
                    Dir. {activeTrailerFilm.director} • {activeTrailerFilm.runtime}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTrailerFilm(null)}
                  className="p-1.5 rounded-lg bg-[#090D16] border border-[#232936] text-[#9CA3AF] hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 aspect-video rounded-xl overflow-hidden bg-gradient-to-br from-neutral-900 via-zinc-950 to-black border border-red-950/40 relative flex items-center justify-center">
                <div className="relative z-10 flex flex-col items-center gap-3 p-6 text-center">
                  <a
                    href={activeTrailerFilm.trailerUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="w-14 h-14 rounded-full bg-[#E50914] hover:bg-[#B80710] text-white flex items-center justify-center shadow-[0_0_30px_rgba(229,9,20,0.7)] transition-transform hover:scale-110 active:scale-95"
                  >
                    <Play className="w-6 h-6 fill-current ml-0.5" />
                  </a>
                  <div>
                    <span className="text-sm font-bold text-white block">
                      Launch External 4K Trailer
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-[#232936] flex items-center justify-between text-xs font-mono text-[#9CA3AF]">
                <span>Source: Letterboxd Screening Engine</span>
                <button
                  type="button"
                  onClick={() => setActiveTrailerFilm(null)}
                  className="px-4 py-1.5 rounded-lg bg-[#E50914] text-white font-semibold hover:bg-[#B80710] transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
