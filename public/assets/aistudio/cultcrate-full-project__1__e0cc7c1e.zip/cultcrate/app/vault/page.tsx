'use client';

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'motion/react';
import {
  Upload,
  FileText,
  Sparkles,
  Sliders,
  LogOut,
  Star,
  ExternalLink,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  Play,
  Bookmark,
  Tv,
  Film,
  AlertTriangle,
  X,
  Radio,
  Clock,
  Settings,
  Database,
  ArrowRight,
  Terminal,
} from 'lucide-react';
import { createClient } from '@/utils/supabase/client';
import { clearClientStorage } from '@/lib/vaultStorage';
import type { User as SupabaseUser } from '@supabase/supabase-js';
import MovieCard from '@/components/MovieCard';

// Parsed Movie Record from Letterboxd CSV
interface ParsedMovie {
  title: string;
  year?: string;
  letterboxdUrl?: string;
  rating?: string;
}

// Recommended Film Card Interface
interface RecommendedFilm {
  id: string;
  title: string;
  originalTitle?: string;
  year: number;
  runtime: string;
  country: string;
  countryFlag?: string;
  director: string;
  imdbRating: string;
  letterboxdRating: string;
  posterUrl: string;
  matchScore: string;
  obscurityBadge: string;
  obscurityLevel?: number;
  streamingPlatforms: string[];
  whereToWatchInIndia?: string[];
  contentAdvisory?: string;
  advisory?: string;
  synopsis: string;
  curatorialReason: string;
  trailerUrl?: string;
  letterboxdUrl?: string;
}

// Initial Sample Masterpiece Cohort
const INITIAL_MASTERPIECE_COHORT: RecommendedFilm[] = [
  {
    id: 'memories-of-murder-2003',
    title: 'Memories of Murder',
    originalTitle: '살인의 추억',
    year: 2003,
    runtime: '131 min',
    country: 'South Korea',
    countryFlag: '🇰🇷',
    director: 'Bong Joon-ho',
    imdbRating: '8.1',
    letterboxdRating: '4.3',
    posterUrl: '',
    matchScore: '99.4%',
    obscurityBadge: 'Tier 4 // Masterpiece Cohort',
    obscurityLevel: 4,
    streamingPlatforms: ['Prime Video', 'MUBI', 'Criterion Channel'],
    whereToWatchInIndia: ['Prime Video India', 'MUBI India', 'Apple TV (Rent/Buy)'],
    contentAdvisory: 'Psychological Tension & Grim Investigation Procedures',
    synopsis:
      "In a rural Korean province in 1986, two vastly mismatched detectives struggle with crude methodology and obsessive desperation while hunting South Korea's first recorded serial murderer.",
    curatorialReason:
      "Matches your high rating for Bong Joon-ho's razor-sharp pacing, rain-soaked chiaroscuro cinematography, and moral ambiguity seen in Zodiac and Parasite.",
    trailerUrl: 'https://www.youtube.com/results?search_query=Memories+of+Murder+2003+official+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/memories-of-murder/',
  },
  {
    id: 'cure-1997',
    title: 'Cure',
    originalTitle: 'キュア',
    year: 1997,
    runtime: '111 min',
    country: 'Japan',
    countryFlag: '🇯🇵',
    director: 'Kiyoshi Kurosawa',
    imdbRating: '7.5',
    letterboxdRating: '4.1',
    posterUrl: '',
    matchScore: '98.9%',
    obscurityBadge: 'Tier 4 // Masterpiece Cohort',
    obscurityLevel: 4,
    streamingPlatforms: ['Criterion Channel', 'Apple TV'],
    whereToWatchInIndia: ['MUBI India', 'Apple TV Store India', 'Criterion Channel (VPN)'],
    contentAdvisory: 'Hypnotic Psychological Thriller & Existential Dread',
    synopsis:
      'A detective investigates a string of bizarre, gruesome murders committed by ordinary citizens who retain no recollection of their deeds after encountering an enigmatic amnesiac wanderer.',
    curatorialReason:
      'Clinical detachment, creeping dread, hypnotic soundscapes, and existential terror perfectly aligned with your psychological neo-noir taste vector.',
    trailerUrl: 'https://www.youtube.com/results?search_query=Cure+1997+Kiyoshi+Kurosawa+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/cure/',
  },
  {
    id: 'burning-2018',
    title: 'Burning',
    originalTitle: '버닝',
    year: 2018,
    runtime: '148 min',
    country: 'South Korea',
    countryFlag: '🇰🇷',
    director: 'Lee Chang-dong',
    imdbRating: '7.5',
    letterboxdRating: '4.0',
    posterUrl: '',
    matchScore: '98.1%',
    obscurityBadge: 'Tier 4 // Masterpiece Cohort',
    obscurityLevel: 4,
    streamingPlatforms: ['Netflix', 'MUBI', 'Prime Video'],
    whereToWatchInIndia: ['Prime Video India', 'MUBI India', 'Netflix India'],
    contentAdvisory: 'Slow-burn Atmospheric Tension & Ambiguous Enigma',
    synopsis:
      'An aspiring young writer becomes entangled with an enigmatic acquaintance and a wealthy, charismatic man she meets on a trip, leading to an obsessive disappearance investigation.',
    curatorialReason:
      'Haruki Murakami adaptation echoing your high affinity for Drive My Car. Exceptional ambient natural lighting and subtle class friction.',
    trailerUrl: 'https://www.youtube.com/results?search_query=Burning+2018+Lee+Chang-dong+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/burning-2018/',
  },
];

// Initial Sample Excellent Gems Cohort
const INITIAL_EXCELLENT_COHORT: RecommendedFilm[] = [
  {
    id: 'possession-1981',
    title: 'Possession',
    originalTitle: 'Possession',
    year: 1981,
    runtime: '124 min',
    country: 'France / Germany',
    countryFlag: '🇫🇷',
    director: 'Andrzej Żuławski',
    imdbRating: '7.3',
    letterboxdRating: '4.2',
    posterUrl: '',
    matchScore: '97.2%',
    obscurityBadge: 'Tier 4 // Excellent Gem',
    obscurityLevel: 4,
    streamingPlatforms: ['Metrograph at Home', 'Shudder'],
    whereToWatchInIndia: ['MUBI India', 'Apple TV (VOD Rent)', 'Criterion Channel (VPN)'],
    contentAdvisory: 'Severe Psychological Hysteria & Surrealist Body Horror',
    synopsis:
      'Set against the Cold War backdrop of the Berlin Wall, an intelligence spy returns home to his unraveling marriage only to discover his wife has formed an unspeakable metaphysical liaison.',
    curatorialReason:
      'Synthesized from your high affinity for visceral body horror, unhinged dual performances, and intense existential allegories.',
    trailerUrl: 'https://www.youtube.com/results?search_query=Possession+1981+Zulawski+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/possession-1981/',
  },
  {
    id: 'on-the-silver-globe-1988',
    title: 'On the Silver Globe',
    originalTitle: 'Na srebrnym globie',
    year: 1988,
    runtime: '166 min',
    country: 'Poland',
    countryFlag: '🇵🇱',
    director: 'Andrzej Żuławski',
    imdbRating: '7.2',
    letterboxdRating: '4.0',
    posterUrl: '',
    matchScore: '96.5%',
    obscurityBadge: 'Tier 4 // Excellent Gem',
    obscurityLevel: 4,
    streamingPlatforms: ['Eastern Promises', 'Kino Lorber Cult'],
    whereToWatchInIndia: ['Eastern Promises India', 'MUBI India', 'Archival 4K / YouTube Cinema'],
    contentAdvisory: 'Hallucinatory Sci-Fi Metaphysics & Pagan Savagery',
    synopsis:
      'Astronauts crash-land on an alien world and establish a primal society that gradually devolves into religious mythology, tribal wars, and pagan savagery over subsequent generations.',
    curatorialReason:
      'A restored Polish science fiction odyssey that pushed European cinema to its absolute ecstatic, philosophical limits.',
    trailerUrl: 'https://www.youtube.com/results?search_query=On+the+Silver+Globe+1988+trailer',
    letterboxdUrl: 'https://letterboxd.com/film/on-the-silver-globe/',
  },
];

// Sample Pre-Formatted Letterboxd CSV Data for 1-Click Instant Testing
const SAMPLE_LETTERBOXD_CSV = `Date,Name,Year,Letterboxd URI,Rating
2024-03-01,Memories of Murder,2003,https://letterboxd.com/film/memories-of-murder/,5.0
2024-03-04,Cure,1997,https://letterboxd.com/film/cure/,4.5
2024-03-08,Burning,2018,https://letterboxd.com/film/burning-2018/,4.5
2024-03-12,Possession,1981,https://letterboxd.com/film/possession-1981/,4.5
2024-03-15,The Conversation,1974,https://letterboxd.com/film/the-conversation/,4.0
2024-03-18,Stalker,1979,https://letterboxd.com/film/stalker/,5.0
2024-03-22,Chungking Express,1994,https://letterboxd.com/film/chungking-express/,4.5
2024-03-25,High and Low,1963,https://letterboxd.com/film/high-and-low/,4.5
2024-03-28,Perfect Blue,1997,https://letterboxd.com/film/perfect-blue/,4.5
2024-04-02,On the Silver Globe,1988,https://letterboxd.com/film/on-the-silver-globe/,4.0
2024-04-06,Paris Texas,1984,https://letterboxd.com/film/paris-texas/,5.0
2024-04-10,Solaris,1972,https://letterboxd.com/film/solaris-1972/,4.0`;

export default function VaultPage() {
  const router = useRouter();
  const supabase = createClient();

  // Supabase Auth State
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Requirements 1 & 2: Persistent Storage Check & hasSavedCsv State
  const [hasSavedCsv, setHasSavedCsv] = useState<boolean>(false);
  const [isCsvUploaded, setIsCsvUploaded] = useState<boolean>(false);
  const [isStorageSynced, setIsStorageSynced] = useState<boolean>(false);
  const [isCheckingStorage, setIsCheckingStorage] = useState<boolean>(true);
  const [activeFileName, setActiveFileName] = useState<string | null>(null);
  const [syncStatus, setSyncStatus] = useState<string>('Checking Vault Storage...');
  const [isUploadingToStorage, setIsUploadingToStorage] = useState<boolean>(false);

  // Letterboxd CSV Parser State
  const [parsedMovies, setParsedMovies] = useState<ParsedMovie[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Filter & Curatorial Tuning States
  const [obscurityLevel, setObscurityLevel] = useState<number>(4);
  const [isFamilySafe, setIsFamilySafe] = useState<boolean>(false);
  const [selectedVibes, setSelectedVibes] = useState<string[]>([
    '🧠 Mind-Bending',
    '🔪 Dark Thriller',
    '🤯 Mind Twist',
  ]);
  const [runtimeFilter, setRuntimeFilter] = useState<'any' | '<90' | '<=120' | '140+'>('<=120');

  // Cohort Feed States
  const [activeCohortTab, setActiveCohortTab] = useState<'masterpiece' | 'excellent' | 'all'>('masterpiece');
  const [sortBy, setSortBy] = useState<'affinity' | 'year' | 'rating'>('affinity');
  const [masterpieceCohort, setMasterpieceCohort] = useState<RecommendedFilm[]>(INITIAL_MASTERPIECE_COHORT);
  const [excellentCohort, setExcellentCohort] = useState<RecommendedFilm[]>(INITIAL_EXCELLENT_COHORT);
  const [tasteProfile, setTasteProfile] = useState<string>(
    'Synthesized from high weights in non-linear chronology, rain-drenched chiaroscuro lighting, and morally gray investigator tropes.'
  );
  const [tasteProfileSummary, setTasteProfileSummary] = useState<string>(
    'Synthesized from high weights in non-linear chronology, rain-drenched chiaroscuro lighting, and morally gray investigator tropes.'
  );
  const [tasteDnaTags, setTasteDnaTags] = useState<string[]>([
    'Neo-Noir Chiaroscuro',
    'Atmospheric Dread',
    'Slow-Burn Paranoia',
    'Auteur Psychology',
  ]);

  // Watchlist & Trailer
  const [watchlistIds, setWatchlistIds] = useState<string[]>(['memories-of-murder-2003']);
  const [activeTrailerFilm, setActiveTrailerFilm] = useState<RecommendedFilm | null>(null);

  // Visual Mobile Debugger State
  const [isParsing, setIsParsing] = useState(false);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [liveExecutionStep, setLiveExecutionStep] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedError, setCopiedError] = useState(false);
  const [aiNotice, setAiNotice] = useState<string | null>(null);

  // Obscurity Level Labels
  const obscurityLabels: Record<number, string> = {
    1: 'Lvl 1: Mainstream Hits',
    2: 'Lvl 2: Indiewire Circuit',
    3: 'Lvl 3: Festival Curations',
    4: 'Lvl 4: Deep Arthouse',
    5: 'Lvl 5: Underground Cult',
  };

  // -------------------------------------------------------------
  // CLIENT-SIDE CSV PARSER
  // -------------------------------------------------------------
  const parseCSVContent = useCallback((content: string) => {
    setIsParsing(true);
    setErrorMessage(null);

    try {
      if (!content || !content.trim()) {
        throw new Error('The uploaded file appears to be empty.');
      }

      // Robust Tokenizer handling quoted lines and commas
      const lines: string[] = [];
      let currentLine = '';
      let insideQuote = false;

      for (let i = 0; i < content.length; i++) {
        const char = content[i];
        const nextChar = content[i + 1];

        if (char === '"') {
          if (insideQuote && nextChar === '"') {
            currentLine += '"';
            i++;
          } else {
            insideQuote = !insideQuote;
          }
        } else if ((char === '\r' || char === '\n') && !insideQuote) {
          if (char === '\r' && nextChar === '\n') i++;
          if (currentLine.trim()) {
            lines.push(currentLine);
          }
          currentLine = '';
        } else {
          currentLine += char;
        }
      }
      if (currentLine.trim()) {
        lines.push(currentLine);
      }

      if (lines.length < 2) {
        throw new Error('CSV file must contain at least a header row and one film entry.');
      }

      const tokenizeLine = (line: string): string[] => {
        const tokens: string[] = [];
        let token = '';
        let inQuotes = false;
        for (let j = 0; j < line.length; j++) {
          const c = line[j];
          const nc = line[j + 1];
          if (c === '"') {
            if (inQuotes && nc === '"') {
              token += '"';
              j++;
            } else {
              inQuotes = !inQuotes;
            }
          } else if (c === ',' && !inQuotes) {
            tokens.push(token.trim());
            token = '';
          } else {
            token += c;
          }
        }
        tokens.push(token.trim());
        return tokens;
      };

      const headerRow = tokenizeLine(lines[0]);
      const normalizedHeaders = headerRow.map((h) =>
        h.toLowerCase().replace(/[^a-z0-9]/g, '')
      );

      const titleIndex = normalizedHeaders.findIndex((h) =>
        ['title', 'name', 'film', 'movietitle'].includes(h)
      );
      const yearIndex = normalizedHeaders.findIndex((h) =>
        ['year', 'releaseyear', 'date'].includes(h)
      );
      const urlIndex = normalizedHeaders.findIndex((h) =>
        ['letterboxduri', 'url', 'uri', 'letterboxdurl', 'link'].includes(h)
      );
      const ratingIndex = normalizedHeaders.findIndex((h) =>
        ['rating', 'yourrating', 'score'].includes(h)
      );

      if (titleIndex === -1) {
        throw new Error(
          'Missing "Title" or "Name" column in CSV. Please ensure this is a Letterboxd watchlist, diary, or ratings export.'
        );
      }

      const extracted: ParsedMovie[] = [];

      for (let i = 1; i < lines.length; i++) {
        const row = tokenizeLine(lines[i]);
        const title = row[titleIndex];
        if (!title) continue;

        const year = yearIndex !== -1 && row[yearIndex] ? row[yearIndex] : undefined;
        const letterboxdUrl =
          urlIndex !== -1 && row[urlIndex]
            ? row[urlIndex]
            : `https://letterboxd.com/film/${encodeURIComponent(
                title.toLowerCase().replace(/[^a-z0-9]+/g, '-')
              )}/`;
        const rating = ratingIndex !== -1 && row[ratingIndex] ? row[ratingIndex] : undefined;

        extracted.push({
          title,
          year,
          letterboxdUrl,
          rating,
        });
      }

      if (extracted.length === 0) {
        throw new Error('No valid film records could be extracted from this CSV.');
      }

      setParsedMovies(extracted);
      return extracted;
    } catch (err: unknown) {
      console.error('CSV Parsing Error:', err);
      const msg = err instanceof Error ? err.message : 'Failed to parse Letterboxd CSV file.';
      setErrorMessage(msg);
      return [];
    } finally {
      setIsParsing(false);
    }
  }, []);

  // -------------------------------------------------------------
  // REQUIREMENT 2: FRONTEND DASHBOARD STORAGE CHECK ON MOUNT
  // Checks supabase.storage.from('user_watchlists').list(`${user.id}`)
  // If watchlist.csv exists, sets hasSavedCsv = true and updates status indicator
  // -------------------------------------------------------------
  useEffect(() => {
    async function loadUserDataAndCheckStorage() {
      try {
        const {
          data: { user: currentUser },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !currentUser) {
          router.push('/auth');
          return;
        }

        setUser(currentUser);
        setIsCheckingStorage(true);

        let storageFileFound = false;
        let resolvedFileName = 'watchlist.csv';

        // 1. Check directory `${user.id}` in bucket 'user_watchlists'
        try {
          const { data: userDirList, error: listError } = await supabase.storage
            .from('user_watchlists')
            .list(currentUser.id);

          if (!listError && Array.isArray(userDirList) && userDirList.length > 0) {
            const match = userDirList.find(
              (f) =>
                f.name === 'watchlist.csv' ||
                f.name === 'user_watchlist.csv' ||
                f.name.endsWith('.csv')
            );
            if (match) {
              storageFileFound = true;
              resolvedFileName = match.name;
            }
          }
        } catch (listErr) {
          console.warn('Storage list attempt notice for user.id dir:', listErr);
        }

        // 2. Fallback check for `watchlists/${currentUser.id}`
        if (!storageFileFound) {
          try {
            const { data: nestedList } = await supabase.storage
              .from('user_watchlists')
              .list(`watchlists/${currentUser.id}`);

            if (Array.isArray(nestedList) && nestedList.length > 0) {
              const nestedMatch = nestedList.find(
                (f) =>
                  f.name === 'user_watchlist.csv' ||
                  f.name === 'watchlist.csv' ||
                  f.name.endsWith('.csv')
              );
              if (nestedMatch) {
                storageFileFound = true;
                resolvedFileName = nestedMatch.name;
              }
            }
          } catch (nestedListErr) {
            console.warn('Storage list attempt notice for watchlists/user.id:', nestedListErr);
          }
        }

        // 3. Direct download probe if listing was empty or restricted
        if (!storageFileFound) {
          const directProbes = [
            `${currentUser.id}/watchlist.csv`,
            `watchlists/${currentUser.id}/user_watchlist.csv`,
            `${currentUser.id}/user_watchlist.csv`,
          ];
          for (const probePath of directProbes) {
            try {
              const { data: directBlob } = await supabase.storage
                .from('user_watchlists')
                .download(probePath);

              if (directBlob && directBlob.size > 0) {
                storageFileFound = true;
                resolvedFileName = probePath.split('/').pop() || 'watchlist.csv';
                break;
              }
            } catch {
              // Ignore probe failures
            }
          }
        }

        // 4. Update state based on storage status
        if (storageFileFound) {
          setHasSavedCsv(true);
          setIsCsvUploaded(true);
          setIsStorageSynced(true);
          setActiveFileName(resolvedFileName);
          setSyncStatus('Vault Active: watchlist.csv loaded from storage');

          // Download content in background to populate client-side preview chips
          try {
            const downloadPath =
              resolvedFileName === 'user_watchlist.csv'
                ? `watchlists/${currentUser.id}/user_watchlist.csv`
                : `${currentUser.id}/${resolvedFileName}`;

            const { data: fileBlob } = await supabase.storage
              .from('user_watchlists')
              .download(downloadPath);

            if (fileBlob) {
              const rawText = await fileBlob.text();
              if (rawText && rawText.trim()) {
                parseCSVContent(rawText);
              }
            }
          } catch (blobErr) {
            console.warn('Background preview load notice:', blobErr);
          }
        } else {
          setSyncStatus('Awaiting Watchlist');
        }
      } catch (err) {
        console.error('Failed to load user session:', err);
        router.push('/auth');
      } finally {
        setIsCheckingStorage(false);
        setAuthLoading(false);
      }
    }

    loadUserDataAndCheckStorage();
  }, [supabase, router, parseCSVContent]);

  // Handle Sign Out
  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) await supabase.auth.signOut({ scope: 'local' });
    } catch (err) {
      console.error('Sign out error:', err);
    }
    clearClientStorage();
    router.replace('/auth');
    router.refresh();
  };

  // User details derived from Supabase
  const userEmail = user?.email || 'curator@cultcrate.vault';
  const letterboxdHandle =
    (user?.user_metadata?.letterboxd_username as string) ||
    user?.email?.split('@')[0] ||
    'cinephile_curator';

  // -------------------------------------------------------------
  // DIRECT FILE UPLOAD & STORAGE OVERWRITE
  // Saves directly to user_watchlists bucket at ${user.id}/watchlist.csv
  // -------------------------------------------------------------
  const handleUploadAndSync = async (file: File) => {
    if (!file.name.toLowerCase().endsWith('.csv')) {
      setErrorMessage('Invalid file format. Please upload a Letterboxd .csv watchlist file.');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setErrorMessage('File size exceeds 15MB limit. Please upload a standard Letterboxd export.');
      return;
    }

    setIsParsing(true);
    setIsUploadingToStorage(true);
    setErrorMessage(null);
    setActiveFileName('watchlist.csv');

    try {
      // 1. Direct Supabase Storage Sync (Save directly to ${user.id}/watchlist.csv)
      if (user?.id) {
        const primaryPath = `${user.id}/watchlist.csv`;
        const legacyPath = `watchlists/${user.id}/user_watchlist.csv`;

        // Upload to primary path
        const { error: storageError } = await supabase.storage
          .from('user_watchlists')
          .upload(primaryPath, file, {
            contentType: 'text/csv',
            upsert: true,
          });

        if (storageError) {
          console.warn('Primary storage sync notice:', storageError.message);
        }

        // Also mirror to legacy path for backward compatibility
        await supabase.storage
          .from('user_watchlists')
          .upload(legacyPath, file, {
            contentType: 'text/csv',
            upsert: true,
          })
          .catch(() => {});

        setHasSavedCsv(true);
        setIsCsvUploaded(true);
        setIsStorageSynced(true);
        setSyncStatus('Vault Active: watchlist.csv loaded from storage');
      }

      // 2. Read raw CSV text for local parsing & UI chips preview
      const rawText = await file.text();
      parseCSVContent(rawText);

      setHasSavedCsv(true);
      setIsCsvUploaded(true);
      setIsStorageSynced(true);
      setSyncStatus('Vault Active: watchlist.csv loaded from storage');
      setAiNotice('Watchlist CSV synced directly to your secure vault storage!');
    } catch (err: unknown) {
      console.error('File sync and parse error:', err);
      const msg = err instanceof Error ? err.message : 'Error syncing watchlist file with Supabase Storage.';
      setErrorMessage(msg);
    } finally {
      setIsParsing(false);
      setIsUploadingToStorage(false);
    }
  };

  // File Input Handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    handleUploadAndSync(file);
    if (e.target) e.target.value = '';
  };

  // Drag and Drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    handleUploadAndSync(file);
  };

  // Load Built-In Sample CSV with Storage Sync
  const handleLoadSampleCSV = () => {
    const sampleBlob = new Blob([SAMPLE_LETTERBOXD_CSV], { type: 'text/csv' });
    const sampleFile = new File([sampleBlob], 'watchlist.csv', {
      type: 'text/csv',
    });
    handleUploadAndSync(sampleFile);
  };

  // -------------------------------------------------------------
  // REQUIREMENT 2: RUN CULTCRATE AI ENGINE
  // When user clicks "Run CultCrate AI Engine", do NOT require a file upload.
  // Simply call /api/recommendations letting the backend handle direct fetching.
  // -------------------------------------------------------------
  const handleRunCultCrateAI = async () => {
    setIsSynthesizing(true);
    setErrorMessage(null);

    try {
      const preferenceTags = [
        ...selectedVibes,
        isFamilySafe ? 'Family-Friendly / No Extreme Content' : 'Unfiltered Arthouse',
        `Runtime Aperture: ${runtimeFilter}`,
      ];

      // STEP 1: Live Status Update
      setLiveExecutionStep('Fetching user API key and stored CSV...');
      await new Promise((r) => setTimeout(r, 200));

      // Retrieve active session token for backend authentication
      const { data: sessionData } = await supabase.auth.getSession();
      const sessionToken = sessionData?.session?.access_token;

      // STEP 2: Live Status Update
      setLiveExecutionStep('Sending payload to Gemini 3.8 Flash...');

      // Note: File upload is NOT required here! Backend directly reads from Supabase Storage bucket `user_watchlists`
      const payload: Record<string, any> = {
        username: letterboxdHandle,
        obscurityLevel,
        preferences: preferenceTags,
      };

      // If user has parsed movies in memory, we can pass them as a helpful client fallback
      if (parsedMovies.length > 0) {
        payload.watchlist = parsedMovies;
      }

      const response = await fetch('/api/recommendations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(sessionToken ? { Authorization: `Bearer ${sessionToken}` } : {}),
        },
        body: JSON.stringify(payload),
      });

      // STEP 3: Live Status Update
      setLiveExecutionStep('Received response. Parsing JSON...');
      await new Promise((r) => setTimeout(r, 150));

      if (!response.ok) {
        let exactErrorMessage = `Recommendations endpoint returned HTTP status ${response.status}`;
        try {
          const errorData = await response.json();
          if (errorData && (errorData.error || errorData.message)) {
            exactErrorMessage = errorData.error || errorData.message;
          }
        } catch {
          const rawText = await response.text().catch(() => '');
          if (rawText) exactErrorMessage = rawText;
        }
        throw new Error(exactErrorMessage);
      }

      let data: any;
      try {
        data = await response.json();
      } catch (jsonErr: any) {
        throw new Error(`Invalid JSON received from recommendation engine: ${jsonErr.message || 'Syntax Error'}`);
      }

      if (!data || typeof data !== 'object') {
        throw new Error('Malformed or empty JSON payload returned by CultCrate AI.');
      }

      const rawMasterpiece = data.masterpiece_cohort || data.masterpieceCohort;
      const rawExcellent = data.excellent_cohort || data.excellentCohort;
      const summary = data.taste_profile_summary || data.tasteProfileSummary || data.tasteProfile;

      // Store API response directly into React state
      if (summary && typeof summary === 'string') {
        setTasteProfile(summary);
        setTasteProfileSummary(summary);
      }

      if (data.tasteDnaTags && Array.isArray(data.tasteDnaTags)) {
        setTasteDnaTags(data.tasteDnaTags);
      }

      // Safe mapping helper
      const mapFilm = (f: any, idx: number, isMasterpiece: boolean): RecommendedFilm => {
        const indiaStreaming =
          Array.isArray(f.whereToWatchInIndia) && f.whereToWatchInIndia.length > 0
            ? f.whereToWatchInIndia
            : typeof f.where_to_watch_india === 'string'
            ? f.where_to_watch_india.split(',').map((s: string) => s.trim())
            : Array.isArray(f.where_to_watch_india)
            ? f.where_to_watch_india
            : f.streamingPlatforms && f.streamingPlatforms.length > 0
            ? f.streamingPlatforms
            : ['MUBI India', 'Prime Video India', 'Apple TV (Rent/Buy)'];

        const fallbackPoster = isMasterpiece
          ? INITIAL_MASTERPIECE_COHORT[idx % INITIAL_MASTERPIECE_COHORT.length].posterUrl
          : INITIAL_EXCELLENT_COHORT[idx % INITIAL_EXCELLENT_COHORT.length].posterUrl;

        return {
          id: f.id || `rec-${isMasterpiece ? 'm' : 'e'}-${idx}-${(f.title || 'film').toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
          title: f.title || 'Curated Feature',
          originalTitle: f.originalTitle || f.title,
          year: Number(f.year) || 2020,
          runtime: f.runtime || (f.runtime_mins ? `${f.runtime_mins} min` : '120 min'),
          country: f.country || 'International',
          countryFlag: f.countryFlag || '🌐',
          director: f.director || (isMasterpiece ? 'Visionary Auteur' : 'Underground Auteur'),
          imdbRating: `${f.imdb_rating || f.imdbRating || '7.8'}`,
          letterboxdRating: `${f.letterboxdRating || (Math.min(5.0, (Number(f.imdb_rating || 7.8) / 2) + 0.3)).toFixed(1)}`,
          posterUrl: f.posterUrl || fallbackPoster,
          matchScore: f.matchScore || `${isMasterpiece ? (99.4 - idx * 0.5).toFixed(1) : (97.2 - idx * 0.7).toFixed(1)}%`,
          obscurityBadge: f.obscurityBadge || `Tier ${obscurityLevel} // ${isMasterpiece ? 'Masterpiece Cohort' : 'Excellent Gem'}`,
          obscurityLevel,
          streamingPlatforms: indiaStreaming,
          whereToWatchInIndia: indiaStreaming,
          contentAdvisory: f.content_advisory || f.contentAdvisory || f.advisory || 'Psychological tension & atmospheric immersion',
          advisory: f.content_advisory || f.contentAdvisory || f.advisory || 'Psychological tension & atmospheric immersion',
          synopsis: f.spoiler_free_premise || f.synopsis || 'A singular cinematic meditation challenging conventional narrative constraints.',
          curatorialReason: f.thematic_alignment || f.curatorialReason || 'Matches your high affinity for deep auteur storytelling.',
          trailerUrl:
            f.trailerUrl ||
            `https://www.youtube.com/results?search_query=${encodeURIComponent((f.title || '') + ' official trailer')}`,
          letterboxdUrl:
            f.letterboxdUrl ||
            `https://letterboxd.com/film/${encodeURIComponent((f.title || '').toLowerCase().replace(/[^a-z0-9]+/g, '-'))}/`,
        };
      };

      // Safely map and store masterpieceCohort
      if (Array.isArray(rawMasterpiece) && rawMasterpiece.length > 0) {
        const mappedMasterpiece = rawMasterpiece.map((f, i) => mapFilm(f, i, true));
        setMasterpieceCohort(mappedMasterpiece);
      }

      // Safely map and store excellentCohort
      if (Array.isArray(rawExcellent) && rawExcellent.length > 0) {
        const mappedExcellent = rawExcellent.map((f, i) => mapFilm(f, i, false));
        setExcellentCohort(mappedExcellent);
      }

      setAiNotice(`CultCrate AI successfully curated cohorts for @${letterboxdHandle}!`);
      setLiveExecutionStep(null);
    } catch (err: unknown) {
      console.error('Synthesis error:', err);
      const exactMsg = err instanceof Error ? err.message : String(err);
      setErrorMessage(exactMsg);
      setLiveExecutionStep(null);
    } finally {
      setIsSynthesizing(false);
    }
  };

  // Safe Cohort List derived from state
  const displayedFilms = useMemo(() => {
    const safeMasterpiece = Array.isArray(masterpieceCohort) ? masterpieceCohort : [];
    const safeExcellent = Array.isArray(excellentCohort) ? excellentCohort : [];

    let list: RecommendedFilm[] = [];
    if (activeCohortTab === 'masterpiece') {
      list = [...safeMasterpiece];
    } else if (activeCohortTab === 'excellent') {
      list = [...safeExcellent];
    } else {
      list = [...safeMasterpiece, ...safeExcellent];
    }

    // Apply sorting
    if (sortBy === 'affinity') {
      list.sort((a, b) => parseFloat(b.matchScore) - parseFloat(a.matchScore));
    } else if (sortBy === 'year') {
      list.sort((a, b) => b.year - a.year);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => parseFloat(b.letterboxdRating) - parseFloat(a.letterboxdRating));
    }

    return list;
  }, [activeCohortTab, masterpieceCohort, excellentCohort, sortBy]);

  // Toggle Watchlist
  const toggleWatchlist = (id: string) => {
    setWatchlistIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Toggle Vibe Pill
  const toggleVibe = (vibe: string) => {
    setSelectedVibes((prev) =>
      prev.includes(vibe) ? prev.filter((v) => v !== vibe) : [...prev, vibe]
    );
  };

  // Copy Error details
  const handleCopyError = () => {
    if (errorMessage && typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(errorMessage);
      setCopiedError(true);
      setTimeout(() => setCopiedError(false), 2000);
    }
  };

  // Initial Auth Loading Screen
  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#090D16] flex items-center justify-center font-sans text-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#E50914] flex items-center justify-center animate-pulse shadow-[0_0_25px_rgba(229,9,20,0.5)]">
            <Film className="w-5 h-5 text-white" />
          </div>
          <span className="font-mono text-xs text-[#9CA3AF] tracking-wider uppercase">
            Opening Screening Vault...
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#090D16] text-[#F9FAFB] font-sans selection:bg-[#E50914] selection:text-white pb-24 overflow-x-hidden">
      {/* Background Volumetric Cinematic Glows */}
      <div className="fixed top-20 left-1/3 w-[500px] h-[500px] bg-[#E50914]/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="fixed top-1/2 -right-20 w-[400px] h-[400px] bg-[#F59E0B]/5 rounded-full blur-[120px] pointer-events-none -z-10" />

      {/* 1. Header & Authenticated User Info */}
      <header className="sticky top-0 z-40 bg-[#090D16]/90 backdrop-blur-xl border-b border-[#232936] px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* CultCrate Glowing Logo */}
        <Link href="/" className="flex items-center gap-3 group">
          <div className="relative w-9 h-9 rounded-xl bg-gradient-to-br from-[#E50914] to-[#900008] flex items-center justify-center shadow-lg shadow-[#E50914]/30 group-hover:scale-105 transition-transform duration-200">
            <Film className="w-5 h-5 text-white" />
            <div className="absolute inset-0 rounded-xl bg-[#E50914] blur-sm opacity-40 group-hover:opacity-75 transition-opacity" />
          </div>

          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight text-white leading-none">
              Cult<span className="text-[#E50914]">Crate</span>
            </span>
            <span className="text-[10px] font-mono tracking-wider text-[#9CA3AF] uppercase mt-0.5">
              Screening Vault // Engine
            </span>
          </div>
        </Link>

        {/* Authenticated User Details & Logout Button */}
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-[#121620] border border-[#232936] text-xs font-mono">
            <div className="w-2 h-2 rounded-full bg-[#4EDEAE] animate-pulse" />
            <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2 leading-none">
              <span className="text-white font-semibold">@{letterboxdHandle}</span>
              <span className="hidden md:inline text-[#9CA3AF] text-[11px]">({userEmail})</span>
            </div>
          </div>

          <Link
            href="/settings"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#121620] hover:bg-[#1c2230] border border-[#232936] hover:border-[#E50914]/50 text-xs font-mono text-[#9CA3AF] hover:text-white transition-all cursor-pointer active:scale-95"
            title="Configure Gemini API Key & Vault Settings"
          >
            <Settings className="w-3.5 h-3.5 text-zinc-400 group-hover:text-white" />
            <span className="hidden sm:inline">Settings</span>
          </Link>

          <button
            onClick={handleSignOut}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#121620] hover:bg-[#1c2230] border border-[#232936] hover:border-[#E50914]/50 text-xs font-mono text-[#9CA3AF] hover:text-white transition-all cursor-pointer active:scale-95"
            title="Log out of Screening Vault"
          >
            <LogOut className="w-3.5 h-3.5 text-[#E50914]" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
        {/* VISIBLE MOBILE RED ERROR CARD (HIGH CONTRAST / NO F12 NEEDED) */}
        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.99 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="p-5 rounded-2xl bg-[#1a080a] border-2 border-[#E50914] text-red-100 shadow-[0_0_35px_rgba(229,9,20,0.4)] space-y-3"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#E50914] flex items-center justify-center shrink-0 shadow-[0_0_15px_#E50914]">
                  <XCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                    Curatorial Engine Error / API Failure
                  </h3>
                  <p className="text-[11px] text-red-300 font-mono">
                    Exact server error message (visible without browser devtools):
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleCopyError}
                  className="px-3 py-1.5 rounded-lg bg-black/60 hover:bg-black text-xs font-mono text-red-200 hover:text-white border border-red-500/40 flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Copy exact error to clipboard"
                >
                  {copiedError ? <Check className="w-3.5 h-3.5 text-[#4EDEAE]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedError ? 'Copied!' : 'Copy Error'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setErrorMessage(null)}
                  className="p-1.5 rounded-lg bg-black/60 hover:bg-black text-red-300 hover:text-white border border-red-500/40 transition-colors cursor-pointer"
                  title="Dismiss error"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* EXACT RAW ERROR MESSAGE DISPLAY */}
            <div className="p-3.5 rounded-xl bg-black/80 border border-red-500/50 font-mono text-xs text-red-200 break-all select-all leading-relaxed max-h-48 overflow-y-auto">
              <div className="flex items-center gap-1.5 text-red-400 font-semibold mb-1">
                <Terminal className="w-3.5 h-3.5 text-[#E50914]" />
                <span>Error Payload:</span>
              </div>
              <pre className="whitespace-pre-wrap font-mono text-xs">{errorMessage}</pre>
            </div>

            {/* Actionable Hint / Link if Gemini API Key is missing */}
            {errorMessage.toLowerCase().includes('gemini api key') && (
              <div className="pt-1 flex items-center justify-between flex-wrap gap-2 text-xs font-mono">
                <span className="text-zinc-300">Your Google Gemini API Key has not been configured in Vault settings.</span>
                <Link
                  href="/settings"
                  className="px-3 py-1.5 rounded-lg bg-[#E50914] hover:bg-[#b80710] text-white font-bold inline-flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(229,9,20,0.5)]"
                >
                  <span>Configure Gemini Key in Settings</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            )}
          </motion.div>
        )}

        {/* AI Notice Banner */}
        {aiNotice && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-3.5 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center justify-between gap-2 shadow-[0_0_20px_rgba(78,222,174,0.15)]"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#4EDEAE] shrink-0" />
              <span>{aiNotice}</span>
            </div>
            <button
              onClick={() => setAiNotice(null)}
              className="text-emerald-400 hover:text-white text-xs cursor-pointer"
            >
              ✕
            </button>
          </motion.div>
        )}

        {/* Two-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* ========================================================= */}
          {/* LEFT SIDEBAR: CSV Watchlist Parser & Controls (~5 cols)   */}
          {/* ========================================================= */}
          <aside className="lg:col-span-5 space-y-6 lg:sticky lg:top-24">
            {/* 2. Letterboxd Watchlist Parser Card */}
            <div className="rounded-2xl bg-[#121620]/90 border border-[#232936] p-6 backdrop-blur-xl shadow-xl space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-[#232936]">
                <div className="flex items-center gap-2">
                  <Upload className="w-4 h-4 text-[#E50914]" />
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                    Letterboxd Watchlist Parser
                  </h2>
                </div>

                {/* Persistent Storage Badge */}
                {hasSavedCsv || isCsvUploaded || isStorageSynced ? (
                  <span className="font-mono text-[10px] text-[#4EDEAE] bg-[#4EDEAE]/15 px-2.5 py-1 rounded-full border border-[#4EDEAE]/40 flex items-center gap-1.5 shadow-[0_0_12px_rgba(78,222,174,0.2)]">
                    <Database className="w-3 h-3 text-[#4EDEAE]" />
                    <span className="font-semibold">Vault Active</span>
                  </span>
                ) : (
                  <span className="font-mono text-[10px] text-[#9CA3AF] bg-[#121620] px-2 py-0.5 rounded border border-[#232936]">
                    Awaiting Ingestion
                  </span>
                )}
              </div>

              {/* Loading State during Storage Verification */}
              {isCheckingStorage && (
                <div className="p-4 rounded-xl bg-[#090D16] border border-[#232936] flex items-center gap-2.5 text-xs font-mono text-[#9CA3AF]">
                  <RefreshCw className="w-4 h-4 animate-spin text-[#E50914]" />
                  <span>Verifying user_watchlists bucket storage...</span>
                </div>
              )}

              {/* CASE A: FILE EXISTS (hasSavedCsv === true) */}
              {!isCheckingStorage && (hasSavedCsv || isCsvUploaded) && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 rounded-xl bg-emerald-950/50 border border-[#4EDEAE]/50 text-emerald-100 font-mono text-xs flex items-center justify-between gap-3 shadow-[0_0_20px_rgba(78,222,174,0.15)]"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-[#4EDEAE]/15 border border-[#4EDEAE]/30 flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-5 h-5 text-[#4EDEAE]" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-[#4EDEAE] animate-pulse shadow-[0_0_8px_#4EDEAE]" />
                        <span className="font-bold text-white tracking-wide text-xs">
                          Vault Active // Synced with Storage
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-300 mt-0.5">
                        <code className="text-[#4EDEAE]">{user?.id}/watchlist.csv</code>
                      </p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold text-emerald-400 bg-emerald-900/50 border border-emerald-500/40 shrink-0">
                    Online
                  </span>
                </motion.div>
              )}

              {/* CASE B: FILE DOES NOT EXIST (hasSavedCsv === false) */}
              {!isCheckingStorage && !hasSavedCsv && !isCsvUploaded && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 rounded-xl bg-[#090D16] border border-amber-500/40 text-amber-200 font-mono text-xs space-y-3"
                >
                  <div className="flex items-start gap-2.5">
                    <AlertTriangle className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                    <p className="text-xs text-zinc-200 leading-relaxed">
                      No Watchlist Found. Please upload your Letterboxd CSV in Settings.
                    </p>
                  </div>
                  <Link
                    href="/settings"
                    className="w-full py-2.5 px-3 rounded-lg bg-[#E50914] hover:bg-[#b80710] text-white font-bold text-xs inline-flex items-center justify-center gap-2 transition-all shadow-[0_0_15px_rgba(229,9,20,0.4)]"
                  >
                    <span>Upload CSV in Settings</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </motion.div>
              )}

              {/* Parsed Metrics Bar */}
              <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-[#090D16] border border-[#232936] font-mono text-xs">
                <div>
                  <span className="text-[10px] text-[#9CA3AF] uppercase block">Total Movies</span>
                  <span className="text-sm font-bold text-white truncate block mt-0.5">
                    {hasSavedCsv || isCsvUploaded
                      ? parsedMovies.length > 0
                        ? `${parsedMovies.length} Synced Films Ready`
                        : 'Synced Films Ready'
                      : '0 Films'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-[#9CA3AF] uppercase block">Storage Status</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        hasSavedCsv || isCsvUploaded || isStorageSynced
                          ? 'bg-[#4EDEAE] animate-pulse shadow-[0_0_8px_#4EDEAE]'
                          : parsedMovies.length > 0
                          ? 'bg-[#4EDEAE]'
                          : 'bg-gray-600'
                      }`}
                    />
                    <span
                      className={`font-semibold truncate text-[11px] ${
                        hasSavedCsv || isCsvUploaded || isStorageSynced
                          ? 'text-[#4EDEAE]'
                          : parsedMovies.length > 0
                          ? 'text-[#4EDEAE]'
                          : 'text-[#9CA3AF]'
                      }`}
                    >
                      {syncStatus}
                    </span>
                  </div>
                </div>
              </div>

              {/* Parsed Titles Preview Chips */}
              {parsedMovies.length > 0 && (
                <div className="space-y-1.5">
                  <span className="font-mono text-[10px] text-[#9CA3AF] uppercase tracking-wider block">
                    Recently Ingested Titles:
                  </span>
                  <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
                    {parsedMovies.slice(0, 10).map((m, idx) => (
                      <a
                        key={idx}
                        href={m.letterboxdUrl || '#'}
                        target="_blank"
                        rel="noreferrer"
                        className="px-2 py-0.5 rounded bg-[#121620] border border-[#232936] hover:border-[#E50914] text-[10px] font-mono text-gray-300 hover:text-white flex items-center gap-1 transition-colors"
                      >
                        <span className="truncate max-w-[120px]">{m.title}</span>
                        {m.year && <span className="text-[#9CA3AF]">({m.year})</span>}
                      </a>
                    ))}
                    {parsedMovies.length > 10 && (
                      <span className="px-2 py-0.5 rounded bg-[#121620] border border-[#232936] text-[10px] font-mono text-[#F59E0B]">
                        +{parsedMovies.length - 10} more
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* INLINE LIVE EXECUTION STEP STATUS BAR */}
              {liveExecutionStep && (
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3.5 rounded-xl bg-[#090D16] border border-[#E50914]/60 shadow-[0_0_20px_rgba(229,9,20,0.3)] space-y-1.5"
                >
                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <span className="text-[#E50914] font-bold flex items-center gap-1.5">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#E50914]" />
                      <span>Live Curatorial Status:</span>
                    </span>
                    <span className="text-[#4EDEAE] text-[10px] font-semibold animate-pulse">Running</span>
                  </div>
                  <p className="text-xs font-mono text-white font-semibold">
                    {liveExecutionStep}
                  </p>
                </motion.div>
              )}

              {/* REQUIREMENT 2: Main CTA - Do NOT require file upload; calls /api/recommendations directly */}
              <button
                type="button"
                onClick={handleRunCultCrateAI}
                disabled={isSynthesizing}
                className="w-full py-4 px-4 rounded-xl bg-[#E50914] hover:bg-[#B80710] text-white text-sm font-bold tracking-wide transition-all duration-200 shadow-[0_0_30px_rgba(229,9,20,0.45)] hover:shadow-[0_0_45px_rgba(229,9,20,0.75)] flex items-center justify-center gap-2 disabled:opacity-75 disabled:cursor-not-allowed active:scale-[0.99] cursor-pointer"
              >
                {isSynthesizing ? (
                  <div className="flex items-center gap-2 font-mono text-xs">
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>{liveExecutionStep || 'Analyzing Cinematic DNA & Vector Space...'}</span>
                  </div>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-white" />
                    <span>Run CultCrate AI Engine</span>
                  </>
                )}
              </button>
            </div>

            {/* Curatorial Controls & Tuner Card */}
            <div className="rounded-2xl bg-[#121620]/90 border border-[#232936] p-6 backdrop-blur-xl shadow-xl space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-[#232936]">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-[#F59E0B]" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                    Curatorial Tuning
                  </h3>
                </div>
                <span className="font-mono text-[10px] text-[#F59E0B] bg-[#F59E0B]/10 px-2 py-0.5 rounded border border-[#F59E0B]/30">
                  {obscurityLabels[obscurityLevel]}
                </span>
              </div>

              {/* Obscurity Level Slider */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#9CA3AF]">Obscurity Aperture:</span>
                  <span className="text-[#E50914] font-bold">Tier {obscurityLevel} of 5</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={obscurityLevel}
                  onChange={(e) => setObscurityLevel(Number(e.target.value))}
                  className="w-full accent-[#E50914] bg-[#090D16] h-2 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[9px] font-mono text-[#9CA3AF]">
                  <span>1: Mainstream</span>
                  <span>3: Festival</span>
                  <span>5: Underground</span>
                </div>
              </div>

              {/* Family Safe Filter Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#090D16] border border-[#232936]">
                <div>
                  <span className="text-xs font-semibold text-white block">Family-Friendly Filter</span>
                  <span className="text-[10px] text-[#9CA3AF] font-mono">
                    {isFamilySafe ? 'Strict: Filter out visceral/extreme content' : 'Off: Unfiltered underground canon'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsFamilySafe(!isFamilySafe)}
                  className={`w-10 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                    isFamilySafe ? 'bg-[#4EDEAE] justify-end' : 'bg-[#232936] justify-start'
                  }`}
                >
                  <motion.div
                    layout
                    className={`w-4 h-4 rounded-full ${isFamilySafe ? 'bg-black' : 'bg-gray-400'}`}
                  />
                </button>
              </div>

              {/* Aesthetic Vibe Filters */}
              <div className="space-y-2">
                <span className="text-xs font-mono text-[#9CA3AF] uppercase tracking-wider block">
                  Aesthetic Vectors:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    '🧠 Mind-Bending',
                    '🔪 Dark Thriller',
                    '🤯 Mind Twist',
                    '🌧️ Rain Chiaroscuro',
                    '🪐 Cosmic Dread',
                    '🩸 Visceral Body Horror',
                    '🕵️ Unreliable Narrator',
                  ].map((vibe) => {
                    const isSelected = selectedVibes.includes(vibe);
                    return (
                      <button
                        key={vibe}
                        type="button"
                        onClick={() => toggleVibe(vibe)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#E50914] text-white font-semibold shadow-[0_0_12px_rgba(229,9,20,0.4)]'
                            : 'bg-[#090D16] text-[#9CA3AF] border border-[#232936] hover:text-white'
                        }`}
                      >
                        {vibe}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Runtime Filter */}
              <div className="space-y-2">
                <span className="text-xs font-mono text-[#9CA3AF] uppercase tracking-wider block">
                  Runtime Aperture:
                </span>
                <div className="grid grid-cols-4 gap-1.5 font-mono text-xs">
                  {(['any', '<90', '<=120', '140+'] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRuntimeFilter(r)}
                      className={`py-1.5 px-2 rounded-lg text-center transition-colors cursor-pointer ${
                        runtimeFilter === r
                          ? 'bg-[#1c2230] text-white border border-[#E50914] font-bold'
                          : 'bg-[#090D16] text-[#9CA3AF] border border-[#232936] hover:text-white'
                      }`}
                    >
                      {r === 'any' ? 'Any' : r}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* ========================================================= */}
          {/* RIGHT MAIN AREA: AI Cohorts Feed & Poster Grid (~7 cols) */}
          {/* ========================================================= */}
          <section className="lg:col-span-7 space-y-6">
            {/* Taste Profile Synthesis Box */}
            <div className="rounded-2xl bg-gradient-to-r from-[#121620] via-[#121620] to-[#1a0e14] border border-[#232936] p-6 shadow-xl relative overflow-hidden space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Radio className="w-4 h-4 text-[#E50914] animate-pulse" />
                  <span className="font-mono text-xs text-[#E50914] font-bold uppercase tracking-wider">
                    Cinematic DNA &amp; Vector Space
                  </span>
                </div>
                <span className="font-mono text-[10px] text-[#4EDEAE] bg-[#4EDEAE]/10 border border-[#4EDEAE]/30 px-2 py-0.5 rounded">
                  Calibrated Tier {obscurityLevel}
                </span>
              </div>

              <p className="text-sm text-gray-200 leading-relaxed font-sans">
                {tasteProfile || tasteProfileSummary}
              </p>

              {/* Taste DNA Badges */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {tasteDnaTags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-0.5 rounded-md bg-[#090D16] border border-[#232936] font-mono text-[10px] text-[#9CA3AF] flex items-center gap-1"
                  >
                    <span>#</span>
                    <span>{tag}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Cohort Tabs & Filters Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-2 rounded-xl bg-[#090D16] border border-[#232936]">
              {/* Cohort Filter Tabs */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setActiveCohortTab('masterpiece')}
                  className={`px-3.5 py-2 rounded-lg font-mono text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                    activeCohortTab === 'masterpiece'
                      ? 'bg-[#E50914] text-white shadow-[0_0_15px_rgba(229,9,20,0.5)]'
                      : 'text-[#9CA3AF] hover:text-white hover:bg-[#121620]'
                  }`}
                >
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span>Masterpiece Cohort</span>
                  {Array.isArray(masterpieceCohort) && (
                    <span className="px-1.5 py-0.2 rounded bg-black/40 text-[10px]">
                      {masterpieceCohort.length}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCohortTab('excellent')}
                  className={`px-3.5 py-2 rounded-lg font-mono text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                    activeCohortTab === 'excellent'
                      ? 'bg-[#E50914] text-white shadow-[0_0_15px_rgba(229,9,20,0.5)]'
                      : 'text-[#9CA3AF] hover:text-white hover:bg-[#121620]'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Excellent Cohort</span>
                  {Array.isArray(excellentCohort) && (
                    <span className="px-1.5 py-0.2 rounded bg-black/40 text-[10px]">
                      {excellentCohort.length}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCohortTab('all')}
                  className={`px-3.5 py-2 rounded-lg font-mono text-xs font-semibold transition-all cursor-pointer ${
                    activeCohortTab === 'all'
                      ? 'bg-[#E50914] text-white shadow-[0_0_15px_rgba(229,9,20,0.5)]'
                      : 'text-[#9CA3AF] hover:text-white hover:bg-[#121620]'
                  }`}
                >
                  <span>All Curated</span>
                  {Array.isArray(masterpieceCohort) && Array.isArray(excellentCohort) && (
                    <span className="ml-1.5 px-1.5 py-0.2 rounded bg-black/40 text-[10px]">
                      {masterpieceCohort.length + excellentCohort.length}
                    </span>
                  )}
                </button>
              </div>

              {/* Sorter */}
              <div className="flex items-center gap-2 font-mono text-xs px-2">
                <span className="text-[#9CA3AF] text-[11px] uppercase">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-[#121620] border border-[#232936] text-white text-xs rounded-lg px-2.5 py-1 focus:outline-none focus:border-[#E50914] cursor-pointer"
                >
                  <option value="affinity">Highest Affinity</option>
                  <option value="year">Release Year</option>
                  <option value="rating">Letterboxd Rating</option>
                </select>
              </div>
            </div>

            {/* Cinematic Loading State: "Analyzing Cinematic DNA & Vector Space..." */}
            {isSynthesizing && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="rounded-2xl bg-gradient-to-b from-[#121620] to-[#090D16] border-2 border-[#E50914]/40 p-8 sm:p-10 shadow-[0_0_50px_rgba(229,9,20,0.25)] relative overflow-hidden text-center space-y-6"
              >
                {/* Visual Ambient Radar Glow */}
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#E50914]/15 via-transparent to-transparent pointer-events-none" />

                {/* Rotating Film Reel Animation */}
                <div className="relative mx-auto w-20 h-20 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-2 border-dashed border-[#E50914] animate-[spin_6s_linear_infinite]" />
                  <div className="absolute inset-2 rounded-full border border-[#4EDEAE]/40 animate-[spin_4s_linear_infinite_reverse]" />
                  <div className="w-10 h-10 rounded-full bg-[#E50914] flex items-center justify-center shadow-[0_0_25px_#E50914]">
                    <Film className="w-5 h-5 text-white animate-pulse" />
                  </div>
                </div>

                <div className="space-y-2 relative z-10">
                  <span className="font-mono text-xs text-[#E50914] tracking-widest uppercase font-bold flex items-center justify-center gap-2">
                    <Radio className="w-3.5 h-3.5 animate-pulse text-[#E50914]" />
                    <span>Neural Curatorial Matrix Active</span>
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    Analyzing Cinematic DNA &amp; Vector Space...
                  </h3>
                  <p className="text-xs text-[#9CA3AF] font-mono max-w-md mx-auto leading-relaxed">
                    {liveExecutionStep || `Querying Gemini 3.8 Flash to cross-reference Letterboxd records with Tier ${obscurityLevel} underground archives.`}
                  </p>
                </div>

                {/* Live Vector Telemetry Steps */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-[11px] pt-2">
                  <div className="p-3 rounded-xl bg-[#090D16] border border-[#232936] text-left space-y-1">
                    <span className="text-[#4EDEAE] font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-[#4EDEAE]" /> Vector Ingestion
                    </span>
                    <p className="text-[#9CA3AF] text-[10px]">Auteur affinities &amp; ratings calibrated</p>
                  </div>

                  <div className="p-3 rounded-xl bg-[#090D16] border border-[#E50914]/40 text-left space-y-1">
                    <span className="text-[#E50914] font-semibold flex items-center gap-1.5">
                      <RefreshCw className="w-3 h-3 text-[#E50914] animate-spin" /> Deep Crate Filter
                    </span>
                    <p className="text-[#9CA3AF] text-[10px]">Zero commercial bias filter enforced</p>
                  </div>

                  <div className="p-3 rounded-xl bg-[#090D16] border border-[#232936] text-left space-y-1">
                    <span className="text-[#F59E0B] font-semibold flex items-center gap-1.5">
                      <Tv className="w-3 h-3 text-[#F59E0B]" /> India OTT Geo-Check
                    </span>
                    <p className="text-[#9CA3AF] text-[10px]">MUBI, Prime &amp; Apple TV India availability</p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Film Poster Grid (Safely map & render after verifying array structure) */}
            {!isSynthesizing && (
              <div className="space-y-6">
                {Array.isArray(displayedFilms) && displayedFilms.length > 0 ? (
                  displayedFilms.map((film) => {
                    const isWatchlisted = watchlistIds.includes(film.id);
                    const isMasterpiece =
                      film.obscurityBadge.toLowerCase().includes('masterpiece') ||
                      activeCohortTab === 'masterpiece';

                    return (
                      <article
                        key={film.id}
                        className="rounded-2xl bg-[#121620]/90 border border-[#232936] hover:border-[#E50914]/60 transition-all duration-300 shadow-[0_12px_36px_rgba(0,0,0,0.5)] overflow-hidden group"
                      >
                        <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
                          {/* Left Poster Column */}
                          {/* Left Poster Column: Pure CSS Cinephile Cover */}
                          <div className="md:col-span-4 relative min-h-[320px] md:min-h-full bg-gradient-to-br from-neutral-900 via-zinc-950 to-black border-r border-red-950/40 overflow-hidden flex flex-col justify-end p-4">
                            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none" />

                            {/* Poster Badges */}
                            <div className="relative z-10 space-y-1.5">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="px-2 py-0.5 rounded bg-[#E50914] text-white font-mono text-[10px] font-bold tracking-wider uppercase inline-block shadow-md">
                                  Match {film.matchScore}
                                </span>
                                <span
                                  className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold tracking-wider uppercase inline-block shadow-md ${
                                    isMasterpiece
                                      ? 'bg-[#F59E0B] text-black'
                                      : 'bg-[#4EDEAE] text-black'
                                  }`}
                                >
                                  {isMasterpiece ? 'Masterpiece Cohort' : 'Excellent Gem'}
                                </span>
                              </div>
                              <div className="text-white font-mono text-[11px] font-semibold drop-shadow">
                                Dir. {film.director} • {film.year}
                              </div>
                            </div>
                          </div>

                          {/* Right Details Column */}
                          <div className="md:col-span-8 p-5 sm:p-6 flex flex-col justify-between space-y-4">
                            <div>
                              {/* Header Row: Title & Ratings */}
                              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 mb-2">
                                <div>
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                                      {film.title}
                                    </h3>
                                    {film.originalTitle && film.originalTitle !== film.title && (
                                      <span className="text-xs text-[#9CA3AF] font-medium">
                                        ({film.originalTitle})
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-xs text-[#9CA3AF] font-mono mt-0.5 flex items-center gap-2">
                                    <span>{film.country} {film.countryFlag || '🌐'}</span>
                                    <span>•</span>
                                    <span>{film.year}</span>
                                    <span>•</span>
                                    <span className="flex items-center gap-1">
                                      <Clock className="w-3 h-3 text-[#9CA3AF]" />
                                      {film.runtime}
                                    </span>
                                  </p>
                                </div>

                                {/* Ratings Badges */}
                                <div className="flex items-center gap-1.5 shrink-0">
                                  <span className="px-2 py-0.5 rounded bg-[#F59E0B]/15 border border-[#F59E0B]/40 text-[#F59E0B] font-mono text-xs font-bold flex items-center gap-1">
                                    <Star className="w-3 h-3 fill-[#F59E0B]" />
                                    <span>{film.imdbRating}</span>
                                  </span>
                                  <span className="px-2 py-0.5 rounded bg-[#121620] border border-[#232936] text-[#4EDEAE] font-mono text-xs font-bold flex items-center gap-1">
                                    <span>●</span>
                                    <span>{film.letterboxdRating} LB</span>
                                  </span>
                                </div>
                              </div>

                              {/* Content Advisory Badge */}
                              <div className="my-2 p-2.5 rounded-xl bg-[#090D16] border border-[#F59E0B]/30 flex items-start gap-2">
                                <AlertTriangle className="w-3.5 h-3.5 text-[#F59E0B] shrink-0 mt-0.5" />
                                <div className="text-[11px] font-mono leading-tight">
                                  <span className="text-[#F59E0B] font-bold uppercase tracking-wider block">
                                    Content Advisory:
                                  </span>
                                  <span className="text-gray-300">
                                    {film.contentAdvisory || film.advisory || 'Psychological tension & atmospheric immersion'}
                                  </span>
                                </div>
                              </div>

                              {/* Where to Watch in India */}
                              <div className="my-2.5 p-2.5 rounded-xl bg-[#090D16] border border-[#232936] space-y-1.5">
                                <div className="flex items-center gap-1.5 font-mono text-[10px] text-[#4EDEAE] font-semibold uppercase tracking-wider">
                                  <span>🇮🇳 Where to Watch in India:</span>
                                </div>
                                <div className="flex flex-wrap items-center gap-1.5">
                                  {(film.whereToWatchInIndia || film.streamingPlatforms).map((platform) => (
                                    <span
                                      key={platform}
                                      className="px-2.5 py-1 rounded-lg bg-[#121620] border border-[#232936] hover:border-[#E50914]/50 text-gray-200 font-mono text-[11px] flex items-center gap-1.5 transition-colors"
                                    >
                                      <Tv className="w-3 h-3 text-[#E50914]" />
                                      <span>{platform}</span>
                                    </span>
                                  ))}
                                </div>
                              </div>

                              {/* Spoiler-Free Premise */}
                              <div className="my-2 space-y-1">
                                <span className="font-mono text-[10px] text-[#9CA3AF] uppercase tracking-wider block font-semibold">
                                  Spoiler-Free Premise:
                                </span>
                                <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed">
                                  {film.synopsis}
                                </p>
                              </div>

                              {/* Curatorial Alignment Reason Box */}
                              <div className="mt-3.5 p-3 rounded-xl bg-[#090D16]/90 border border-[#E50914]/30 relative overflow-hidden">
                                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#E50914]" />
                                <div className="flex items-start gap-2">
                                  <Sparkles className="w-4 h-4 text-[#E50914] shrink-0 mt-0.5" />
                                  <div className="space-y-0.5">
                                    <span className="font-mono text-[10px] uppercase tracking-wider text-[#E50914] font-bold block">
                                      Why this matches your Letterboxd DNA:
                                    </span>
                                    <p className="text-xs text-gray-300 leading-snug">
                                      {film.curatorialReason}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Card Action Footer */}
                            <div className="pt-3 border-t border-[#232936]/60 flex flex-wrap items-center justify-between gap-3">
                              <div className="flex items-center gap-2 flex-wrap">
                                {/* Watch Trailer Button */}
                                <button
                                  type="button"
                                  onClick={() => setActiveTrailerFilm(film)}
                                  className="px-3.5 py-1.5 rounded-xl bg-[#E50914]/15 hover:bg-[#E50914] text-[#E50914] hover:text-white border border-[#E50914]/40 font-mono text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_12px_rgba(229,9,20,0.2)]"
                                >
                                  <Play className="w-3.5 h-3.5 fill-current" />
                                  <span>Watch Trailer</span>
                                </button>

                                {/* Letterboxd Direct Link */}
                                <a
                                  href={film.letterboxdUrl || `https://letterboxd.com/search/${encodeURIComponent(film.title)}/`}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="px-3 py-1.5 rounded-xl bg-[#090D16] hover:bg-[#1c2230] border border-[#232936] hover:border-[#6B7280] text-[#9CA3AF] hover:text-white font-mono text-xs flex items-center gap-1 transition-all"
                                >
                                  <span>Letterboxd</span>
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              </div>

                              <div className="flex items-center gap-2">
                                {/* Watchlist Toggle */}
                                <button
                                  type="button"
                                  onClick={() => toggleWatchlist(film.id)}
                                  className={`px-3 py-1.5 rounded-xl font-mono text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                                    isWatchlisted
                                      ? 'bg-[#4EDEAE]/20 text-[#4EDEAE] border border-[#4EDEAE]/50 shadow-[0_0_12px_rgba(78,222,174,0.3)]'
                                      : 'bg-[#090D16] hover:bg-[#1c2230] text-[#9CA3AF] hover:text-white border border-[#232936]'
                                  }`}
                                >
                                  <Bookmark className={`w-3.5 h-3.5 ${isWatchlisted ? 'fill-[#4EDEAE]' : ''}`} />
                                  <span>{isWatchlisted ? 'Watchlisted' : 'Watchlist'}</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </article>
                    );
                  })
                ) : (
                  <div className="p-12 text-center rounded-2xl bg-[#121620]/60 border border-[#232936] space-y-3 font-mono">
                    <Film className="w-8 h-8 text-[#9CA3AF] mx-auto" />
                    <p className="text-sm text-gray-300 font-semibold">No films found in this cohort tab.</p>
                    <p className="text-xs text-[#9CA3AF]">
                      Select another cohort filter or click &quot;Run CultCrate AI Engine&quot; to curate new titles.
                    </p>
                  </div>
                )}
              </div>
            )}
          </section>
        </div>
      </main>

      {/* Official 4K Trailer Modal */}
      <AnimatePresence>
        {activeTrailerFilm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveTrailerFilm(null)}
              className="fixed inset-0 bg-black/85 backdrop-blur-md"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-2xl bg-[#121620] border border-[#232936] rounded-2xl p-6 shadow-[0_25px_60px_rgba(0,0,0,0.9),0_0_50px_rgba(229,9,20,0.25)] z-10"
            >
              <div className="flex items-start justify-between pb-4 border-b border-[#232936]">
                <div>
                  <span className="font-mono text-[10px] text-[#E50914] uppercase tracking-wider font-bold">
                    Official Screening Trailer
                  </span>
                  <h3 className="text-xl font-bold text-white mt-0.5">
                    {activeTrailerFilm.title} ({activeTrailerFilm.year})
                  </h3>
                  <p className="text-xs text-[#9CA3AF] font-mono">
                    Dir. {activeTrailerFilm.director} • {activeTrailerFilm.runtime}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTrailerFilm(null)}
                  className="p-1.5 rounded-lg bg-[#090D16] border border-[#232936] text-[#9CA3AF] hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Trailer Container: Pure CSS Gradient Backdrop */}
              <div className="mt-4 aspect-video rounded-xl overflow-hidden bg-gradient-to-br from-neutral-900 via-zinc-950 to-black border border-red-950/40 relative flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none" />
                <div className="relative z-10 flex flex-col items-center gap-3 p-6 text-center">
                  <a
                    href={activeTrailerFilm.trailerUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="w-14 h-14 rounded-full bg-[#E50914] hover:bg-[#B80710] text-white flex items-center justify-center shadow-[0_0_30px_rgba(229,9,20,0.7)] transition-transform hover:scale-110 active:scale-95"
                  >
                    <Play className="w-6 h-6 fill-current ml-0.5" />
                  </a>
                  <div>
                    <span className="text-sm font-bold text-white block">
                      Launch External 4K Trailer
                    </span>
                    <span className="text-xs font-mono text-[#9CA3AF]">
                      Opens official trailer stream in high-definition
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-[#232936] flex items-center justify-between text-xs font-mono text-[#9CA3AF]">
                <span>Source: Letterboxd Screening Engine</span>
                <button
                  type="button"
                  onClick={() => setActiveTrailerFilm(null)}
                  className="px-4 py-1.5 rounded-lg bg-[#E50914] text-white font-semibold hover:bg-[#B80710] transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
